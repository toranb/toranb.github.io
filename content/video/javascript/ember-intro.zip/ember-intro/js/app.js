App = Ember.Application.create();

App.Router.map(function() {
    this.resource("people", { path: "/" });
});

App.PeopleRoute = Ember.Route.extend({
    model: function() {
        return App.Person.find();
    }
});

App.PeopleView = Ember.View.extend({
    addPerson: function() {
        var newPerson = Ember.Object.create({id: 3, name: this.get('name')});
        App.Person.add(newPerson);
    },
    deletePerson: function(person) {
        App.Person.remove(person);
    }
});

App.Person = Ember.Object.extend({
    id: null,
    name: ''
}).reopenClass({
    people: [],
    add: function(person) {
        this.people.pushObject(person);
    },
    remove: function(person) {
        this.people.removeObject(person);
    },
    find: function() {
        this.people = [{id: 1, name: 'one'}, {id: 2, name: 'two'}];
        return this.people;
    }
});
