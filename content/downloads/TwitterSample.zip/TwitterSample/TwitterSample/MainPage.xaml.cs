﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;
using TwitterSample.Silverlight.Components.DTO;

namespace TwitterSample
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            Refresh.Click += new System.Windows.RoutedEventHandler(Refresh_Click);
            UpdateStatus.Click += new System.Windows.RoutedEventHandler(UpdateStatus_Click);

            RequestTimelineFromTwitterAPI();
        }

        void Refresh_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(() => RefreshTheTimeline());
        }

        void UpdateStatus_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            SubmitMessage();
        }

        public void SubmitMessage()
        {
            string statusupdate = "status=" + StatusMessage.Text;
            WebRequest.RegisterPrefix("https://", System.Net.Browser.WebRequestCreator.ClientHttp);

            WebClient myService = new WebClient();
            myService.AllowReadStreamBuffering = true;
            myService.UseDefaultCredentials = false;
            myService.Credentials = new NetworkCredential("username", "password");

            myService.UploadStringCompleted += new UploadStringCompletedEventHandler(myService_UploadStringCompleted);
            myService.UploadStringAsync(new Uri("https://twitter.com/statuses/update.xml"), statusupdate);

            this.Dispatcher.BeginInvoke(() => ClearTextBoxValue());
        }

        void myService_UploadStringCompleted(object sender, UploadStringCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                StatusMessage.Text = "Status Update Failed: " + e.Error.Message.ToString();
            }
            else
            {
                //do nothing unless you want to update the timeline to get this status update
            }
        }

        public void RequestTimelineFromTwitterAPI()
        {
            WebRequest.RegisterPrefix("https://", System.Net.Browser.WebRequestCreator.ClientHttp);

            WebClient myService = new WebClient();
            myService.AllowReadStreamBuffering = true;
            myService.UseDefaultCredentials = false;
            myService.Credentials = new NetworkCredential("username", "password");
            myService.DownloadStringCompleted += new DownloadStringCompletedEventHandler(TimelineRequestCompleted);
            myService.DownloadStringAsync(new Uri("https://twitter.com/statuses/friends_timeline.xml"));
        }

        public void TimelineRequestCompleted(object sender, System.Net.DownloadStringCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                StatusMessage.Text = "This application must be installed first";
            }
            else
            {
                List<TwitterStatus> StatusCollection = new List<TwitterStatus>();
                XDocument xdoc = XDocument.Parse(e.Result.ToString());

                StatusCollection = (from status in xdoc.Descendants("status")
                                    select new TwitterStatus
                                    {
                                        Text = status.Element("text").Value,
                                        User = status.Element("user").Element("screen_name").Value
                                    }).ToList();

                this.Dispatcher.BeginInvoke(() => CallDatabindMethod(StatusCollection));
            }
        }

        private object CallDatabindMethod(List<TwitterStatus> StatusCollection)
        {
            Tweeple.ItemsSource = StatusCollection;

            return null;
        }

        public object ClearTextBoxValue()
        {
            StatusMessage.Text = "";

            return null;
        }

        public object RefreshTheTimeline()
        {
            RequestTimelineFromTwitterAPI();

            return null;
        }
    }
}
