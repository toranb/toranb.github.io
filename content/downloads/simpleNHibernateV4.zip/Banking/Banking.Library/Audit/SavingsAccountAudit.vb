﻿Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Banking.Library.Entity
Imports Persistence.Audit

Namespace Audit
    Public Class SavingsAccountAudit
        Implements IAuditor

        Public Sub AuditDelete() Implements Persistence.Audit.IAuditor.AuditDelete
            InsertSavingsAccountAudit("Delete")
        End Sub

        Public Sub AuditInsert() Implements Persistence.Audit.IAuditor.AuditInsert
            InsertSavingsAccountAudit("Insert")
        End Sub

        Public Sub AuditUpdate() Implements Persistence.Audit.IAuditor.AuditUpdate
            InsertSavingsAccountAudit("Update")
        End Sub

        Private Sub InsertSavingsAccountAudit(ByVal AuditType As String)
            'DatabaseFactory.CreateDatabase().ExecuteNonQuery("?")
        End Sub
    End Class
End Namespace