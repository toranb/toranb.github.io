INSERT INTO dbo.tbl_Banking_User VALUES ('Toran','Billups','3402 Ash DR SW','Bondurant','IA','50035','5157795670')

INSERT INTO dbo.tbl_Banking_Account VALUES ('Checking',20.00,1)
INSERT INTO dbo.tbl_Banking_Account VALUES ('Savings',100.00,1)

INSERT INTO dbo.tbl_Banking_CheckingAccount VALUES (1,'info','additional')

INSERT INTO dbo.tbl_Banking_SavingsAccount VALUES (2,'info2')