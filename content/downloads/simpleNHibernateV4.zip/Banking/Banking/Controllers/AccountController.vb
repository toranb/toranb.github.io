Imports Banking.Library.Service.Interfaces
Imports Banking.Library.Service
Imports Banking.Library.Entity
Imports NHibernate
Imports NHibernate.Linq
Imports System.IO
Imports System.Text
Imports System
Imports Persistence.SessionBuilder.Interfaces
Imports Persistence.SessionBuilder

<HandleError()> _
Public Class AccountController
    Inherits System.Web.Mvc.Controller

    Private mAccountService As IAccountService

    Public Sub New()
        Me.New(New AccountService())
    End Sub

    Public Sub New(ByVal AccountService As IAccountService)
        mAccountService = AccountService
    End Sub

    '
    ' GET: /Account/

    Function Index() As ActionResult
        Dim AccountList As List(Of Account) = mAccountService.GetAccountCollection()

        Return View(AccountList)
    End Function

    '
    ' GET: /Account/Edit

    Function Edit(ByVal id As Integer) As ActionResult
        Dim Account As Account = mAccountService.GetAccountById(id)

        'only added to show how lazy loading works :P
        Dim x As String = Account.User.FirstName

        Return View(Account)
    End Function

    '
    ' POST: /Account/Edit/1

    <AcceptVerbs(HttpVerbs.Post)> _
    Function Edit(ByVal id As Integer, ByVal collection As FormCollection) As ActionResult
        Dim Account As Account = mAccountService.GetAccountById(id)

        Account.Balance = 0

        mAccountService.SaveAccount(Account)

        Return View(Account)
    End Function

    '
    ' POST: /Account/Delete/1

    <AcceptVerbs(HttpVerbs.Post)> _
    Function Delete(ByVal id As Integer) As ActionResult
        Dim Account As Account = mAccountService.GetAccountById(id)

        mAccountService.DeleteAccount(Account)

        Return View()
    End Function

    '
    ' POST: /Account/Create/1

    <AcceptVerbs(HttpVerbs.Post)> _
    Function Create(ByVal collection As FormCollection) As ActionResult
        Dim NewAccount As New Account()

        mAccountService.SaveAccount(NewAccount)

        Return View()
    End Function

End Class
