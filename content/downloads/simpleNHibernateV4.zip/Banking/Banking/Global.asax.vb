﻿Imports System.Web.SessionState
Imports System.Reflection
Imports NHibernate
Imports NHibernate.Context
Imports Persistence.SessionBuilder

Public Class MvcApplication
    Inherits System.Web.HttpApplication

    Shared Sub RegisterRoutes(ByVal routes As RouteCollection)
        routes.IgnoreRoute("{resource}.axd/{*pathInfo}")
        ' MapRoute takes the following parameters, in order:
        ' (1) Route name
        ' (2) URL with parameters
        ' (3) Parameter defaults
        routes.MapRoute( _
            "Default", _
            "{controller}.aspx/{action}/{id}", _
            New With {.controller = "User", .action = "Index", .id = ""} _
        )
        routes.MapRoute( _
            "Root", _
            "", _
            New With {.controller = "User", .action = "Index", .id = ""} _
        )
    End Sub

    Sub Application_Start()
        RegisterRoutes(RouteTable.Routes)
        'HibernatingRhinos.NHibernate.Profiler.Appender.NHibernateProfiler.Initialize()
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        Dim session As ISession = CurrentSessionContext.Unbind(SessionBuilderFactory.CurrentBuilder.GetSessionFactory())

        If session IsNot Nothing Then
            Try
                If session.Transaction.IsActive Then
                    session.Transaction.Rollback()
                End If
            Catch ex As Exception

            End Try
        End If
    End Sub
End Class
