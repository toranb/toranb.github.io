﻿Imports Banking.Library.Entity

Namespace Entity.Interfaces
    Public Interface ICheckingAccount
        Property ID() As Integer
        Property CheckingInfo() As String
        Property AdditionalInfo() As String
    End Interface
End Namespace
