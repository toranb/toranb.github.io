﻿Imports Microsoft.Practices.EnterpriseLibrary.Validation.Validators
Imports Validation.Entities
Imports Banking.Library.Service
Imports Banking.Library.Service.Interfaces
Imports Banking.Library.Entity.Interfaces

Namespace Entity
    Public Class CheckingAccount
        Inherits Account
        Implements ICheckingAccount

        Public Sub New()

        End Sub

        Public Sub New(ByVal ID As Integer, ByVal CheckingInfo As String, ByVal AdditionalInfo As String)
            mID = ID
            mCheckingInfo = CheckingInfo
            mAdditionalInfo = AdditionalInfo
        End Sub

        Private mID As Integer
        Public Overridable Property ID() As Integer Implements ICheckingAccount.ID
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mCheckingInfo As String
        Public Overridable Property CheckingInfo() As String Implements ICheckingAccount.CheckingInfo
            Get
                Return mCheckingInfo
            End Get
            Set(ByVal value As String)
                mCheckingInfo = value
            End Set
        End Property

        Private mAdditionalInfo As String
        Public Overridable Property AdditionalInfo() As String Implements ICheckingAccount.AdditionalInfo
            Get
                Return mAdditionalInfo
            End Get
            Set(ByVal value As String)
                mAdditionalInfo = value
            End Set
        End Property

    End Class
End Namespace
