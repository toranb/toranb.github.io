﻿Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Banking.Library.Entity
Imports Persistence.Audit

Namespace Audit
    Public Class AccountAudit
        Implements IAuditor

        Public Sub AuditDelete() Implements Persistence.Audit.IAuditor.AuditDelete
            InsertAccountAudit("Delete")
        End Sub

        Public Sub AuditInsert() Implements Persistence.Audit.IAuditor.AuditInsert
            InsertAccountAudit("Insert")
        End Sub

        Public Sub AuditUpdate() Implements Persistence.Audit.IAuditor.AuditUpdate
            InsertAccountAudit("Update")
        End Sub

        Private Sub InsertAccountAudit(ByVal AuditType As String)
            'DatabaseFactory.CreateDatabase().ExecuteNonQuery("?")
        End Sub
    End Class
End Namespace