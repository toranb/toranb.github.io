﻿Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Banking.Library.Entity
Imports Persistence.Audit

Namespace Audit
    Public Class UserAudit
        Implements IAuditor

        Public Sub AuditDelete() Implements Persistence.Audit.IAuditor.AuditDelete
            InsertUserAudit("Delete")
        End Sub

        Public Sub AuditInsert() Implements Persistence.Audit.IAuditor.AuditInsert
            InsertUserAudit("Insert")
        End Sub

        Public Sub AuditUpdate() Implements Persistence.Audit.IAuditor.AuditUpdate
            InsertUserAudit("Update")
        End Sub

        Private Sub InsertUserAudit(ByVal AuditType As String)
            'DatabaseFactory.CreateDatabase().ExecuteNonQuery("?")
        End Sub
    End Class
End Namespace