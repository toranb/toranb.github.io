﻿Imports System
Imports Banking
Imports System.Text
Imports System.Web.Mvc
Imports Banking.Library.Entity
Imports System.Collections.Generic
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()> _
Public Class UserControllerTest

    <TestMethod()> _
    Public Sub Should_Update_User_And_Reflect_Changes_When_We_Query_User_By_Id()
        Dim Controller As UserController = New UserController()

        'call the edit to update the user object
        Dim UpdateResult As ViewResult = Controller.Edit(1, Nothing)

        'now pull the user back out and verify the address was updated
        Dim GetController As UserController = New UserController()

        Dim GetResult As ViewResult = GetController.Edit(1)

        Dim GetModel As User = DirectCast(GetResult.ViewData.Model, User)

        Assert.AreEqual(GetModel.ID, 1)
        Assert.AreEqual(GetModel.FirstName, "Toran")
        Assert.AreEqual(GetModel.LastName, "Billups")
        Assert.AreEqual(GetModel.Address, "1016 Cameron")
        Assert.AreEqual(GetModel.City, "Bondurant")
        Assert.AreEqual(GetModel.State, "IA")
        Assert.AreEqual(GetModel.Zip, "50035")
        Assert.AreEqual(GetModel.Phone, "5157795670")
    End Sub

    <TestMethod()> _
    Public Sub Should_Delete_User()
        Dim Controller As UserController = New UserController()

        Dim DeleteResult As ViewResult = Controller.Delete(1)

        'now attempt to get this user
        Dim GetController As UserController = New UserController()

        Dim GetResult As ViewResult = GetController.Edit(1)

        Dim GetModel As User = DirectCast(GetResult.ViewData.Model, User)

        Assert.AreEqual(GetModel, Nothing)
    End Sub

    <TestMethod()> _
    Public Sub Should_Create_User()
        Dim Controller As UserController = New UserController()

        'call the edit to update the user object
        Dim UpdateResult As ViewResult = Controller.Create(Nothing)

        'now pull the user back out and verify the address was updated
        Dim GetController As UserController = New UserController()

        Dim GetResult As ViewResult = GetController.Edit(2)

        Dim GetModel As User = DirectCast(GetResult.ViewData.Model, User)

        Assert.AreEqual(GetModel.ID, 2)
        Assert.AreEqual(GetModel.FirstName, "John")
        Assert.AreEqual(GetModel.LastName, "Doe")
        Assert.AreEqual(GetModel.Address, "400 N. 1st")
        Assert.AreEqual(GetModel.City, "Des Moines")
        Assert.AreEqual(GetModel.State, "IA")
        Assert.AreEqual(GetModel.Zip, "50309")
        Assert.AreEqual(GetModel.Phone, "5154010344")
    End Sub

End Class
