USE [Banking]
GO
/****** Object:  StoredProcedure [dbo].[usp_Banking_InsertUserAudit]    Script Date: 09/22/2009 12:35:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[usp_Banking_InsertUserAudit]
@ID int,
@FirstName varchar(100),
@LastName varchar(100),
@Address varchar(100),
@City varchar(100),
@State varchar(100),
@Zip varchar(5),
@Phone varchar(50)
AS

INSERT INTO dbo.[tbl_Banking_User_History] VALUES (
@ID,
@FirstName,
@LastName,
@Address,
@City,
@State,
@Zip,
@Phone,
getdate())
