﻿Imports Banking.Library.DataAccess
Imports Banking.Library.Entity
Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Service.Interfaces

Namespace Service
    Public Class CheckingAccountService
        Implements ICheckingAccountService

        Private mRepository As ICheckingAccountRepository

        Public Sub New()
            Me.New(New CheckingAccountRepository())
        End Sub

        Public Sub New(ByVal Repository As ICheckingAccountRepository)
            mRepository = Repository
        End Sub

        Public Sub DeleteCheckingAccount(ByVal CheckingAccount As CheckingAccount) Implements ICheckingAccountService.DeleteCheckingAccount
            mRepository.DeleteCheckingAccount(CheckingAccount)
        End Sub

        Public Function GetCheckingAccountById(ByVal id As Integer) As CheckingAccount Implements ICheckingAccountService.GetCheckingAccountById
            Return mRepository.GetCheckingAccountById(id)
        End Function

        Public Function GetCheckingAccountCollection() As IQueryable(Of CheckingAccount) Implements ICheckingAccountService.GetCheckingAccountCollection
            Return mRepository.GetCheckingAccountCollection()
        End Function

        Public Sub SaveCheckingAccount(ByVal CheckingAccount As CheckingAccount) Implements ICheckingAccountService.SaveCheckingAccount
            mRepository.SaveCheckingAccount(CheckingAccount)
        End Sub

    End Class
End Namespace
