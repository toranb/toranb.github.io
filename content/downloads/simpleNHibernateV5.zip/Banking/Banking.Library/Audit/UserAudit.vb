﻿Imports Microsoft.Practices.EnterpriseLibrary.Data
Imports Banking.Library.Entity
Imports Persistence.Audit

Namespace Audit
    Public Class UserAudit
        Implements IAuditor

        Private mUser As User

        Public Sub New(ByVal User As User)
            mUser = User
        End Sub

        Public Sub AuditDelete() Implements Persistence.Audit.IAuditor.AuditDelete
            InsertUserAudit("Delete")
        End Sub

        Public Sub AuditInsert() Implements Persistence.Audit.IAuditor.AuditInsert
            InsertUserAudit("Insert")
        End Sub

        Public Sub AuditUpdate() Implements Persistence.Audit.IAuditor.AuditUpdate
            InsertUserAudit("Update")
        End Sub

        Private Sub InsertUserAudit(ByVal AuditType As String)
            DatabaseFactory.CreateDatabase().ExecuteNonQuery("usp_Banking_InsertUserAudit", mUser.ID, mUser.FirstName, mUser.LastName, mUser.Address, mUser.City, mUser.State, mUser.Zip, mUser.Phone)
        End Sub
    End Class
End Namespace