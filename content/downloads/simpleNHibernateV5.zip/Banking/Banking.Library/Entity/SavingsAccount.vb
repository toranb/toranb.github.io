﻿Imports Microsoft.Practices.EnterpriseLibrary.Validation.Validators
Imports Validation.Entities
Imports Banking.Library.Service
Imports Banking.Library.Service.Interfaces
Imports Banking.Library.Entity.Interfaces

Namespace Entity
    Public Class SavingsAccount
        Inherits Account
        Implements ISavingsAccount

        Public Sub New()

        End Sub

        Public Sub New(ByVal ID As Integer, ByVal SavingsInfo As String)
            mID = ID
            mSavingsInfo = SavingsInfo
        End Sub

        Private mID As Integer
        Public Overridable Property ID() As Integer Implements ISavingsAccount.ID
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mSavingsInfo As String
        Public Overridable Property SavingsInfo() As String Implements ISavingsAccount.SavingsInfo
            Get
                Return mSavingsInfo
            End Get
            Set(ByVal value As String)
                mSavingsInfo = value
            End Set
        End Property

    End Class
End Namespace
