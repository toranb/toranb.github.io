﻿Imports Microsoft.Practices.EnterpriseLibrary.Validation.Validators
Imports Validation.Entities
Imports Banking.Library.Service
Imports Banking.Library.Service.Interfaces
Imports Banking.Library.Entity.Interfaces
Imports Persistence.Audit
Imports Banking.Library.Audit

Namespace Entity
    Public Class User
        Inherits BusinessBase(Of User)
        Implements IUser
        Implements IEntityToAudit

        Public Sub New()
            mUserAudit = New UserAudit(Me)
        End Sub

        Public Sub New(ByVal UserAudit As IAuditor)
            mUserAudit = UserAudit
        End Sub

        Public Sub New(ByVal ID As Integer, ByVal FirstName As String, ByVal LastName As String, ByVal Address As String, ByVal City As String, ByVal State As String, ByVal Zip As String, ByVal Phone As String)
            mID = ID
            mFirstName = FirstName
            mLastName = LastName
            mAddress = Address
            mCity = City
            mState = State
            mZip = Zip
            mPhone = Phone
        End Sub

        Private mID As Integer
        Public Overridable Property ID() As Integer Implements IUser.ID
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mFirstName As String
        Public Overridable Property FirstName() As String Implements IUser.FirstName
            Get
                Return mFirstName
            End Get
            Set(ByVal value As String)
                mFirstName = value
            End Set
        End Property

        Private mLastName As String
        Public Overridable Property LastName() As String Implements IUser.LastName
            Get
                Return mLastName
            End Get
            Set(ByVal value As String)
                mLastName = value
            End Set
        End Property

        Private mAddress As String
        Public Overridable Property Address() As String Implements IUser.Address
            Get
                Return mAddress
            End Get
            Set(ByVal value As String)
                mAddress = value
            End Set
        End Property

        Private mCity As String
        Public Overridable Property City() As String Implements IUser.City
            Get
                Return mCity
            End Get
            Set(ByVal value As String)
                mCity = value
            End Set
        End Property

        Private mState As String
        Public Overridable Property State() As String Implements IUser.State
            Get
                Return mState
            End Get
            Set(ByVal value As String)
                mState = value
            End Set
        End Property

        Private mZip As String
        Public Overridable Property Zip() As String Implements IUser.Zip
            Get
                Return mZip
            End Get
            Set(ByVal value As String)
                mZip = value
            End Set
        End Property

        Private mPhone As String
        Public Overridable Property Phone() As String Implements IUser.Phone
            Get
                Return mPhone
            End Get
            Set(ByVal value As String)
                mPhone = value
            End Set
        End Property

        Private mUserAudit As IAuditor
        Public Overridable Property Auditor() As Persistence.Audit.IAuditor Implements Persistence.Audit.IEntityToAudit.Auditor
            Get
                Return mUserAudit
            End Get
            Set(ByVal value As Persistence.Audit.IAuditor)
                mUserAudit = value
            End Set
        End Property
    End Class
End Namespace
