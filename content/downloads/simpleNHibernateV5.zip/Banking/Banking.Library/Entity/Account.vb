﻿Imports Microsoft.Practices.EnterpriseLibrary.Validation.Validators
Imports Validation.Entities
Imports Banking.Library.Service
Imports Banking.Library.Service.Interfaces
Imports Banking.Library.Entity.Interfaces

Namespace Entity
    Public Class Account
        Inherits BusinessBase(Of Account)
        Implements IAccount

        Public Sub New()

        End Sub

        Public Sub New(ByVal BaseID As Integer, ByVal Description As String, ByVal Balance As Nullable(Of Decimal), ByVal UserID As Integer)
            mBaseID = BaseID
            mDescription = Description
            mBalance = Balance
            mUserID = UserID
        End Sub

        Private mBaseID As Integer
        Public Overridable Property BaseID() As Integer Implements IAccount.BaseID
            Get
                Return mBaseID
            End Get
            Set(ByVal value As Integer)
                mBaseID = value
            End Set
        End Property

        Private mDescription As String
        Public Overridable Property Description() As String Implements IAccount.Description
            Get
                Return mDescription
            End Get
            Set(ByVal value As String)
                mDescription = value
            End Set
        End Property

        Private mBalance As Nullable(Of Decimal)
        Public Overridable Property Balance() As Decimal Implements IAccount.Balance
            Get
                Return mBalance
            End Get
            Set(ByVal value As Decimal)
                mBalance = value
            End Set
        End Property

        Private mUserID As Integer
        Public Overridable Property UserID() As Integer Implements IAccount.UserID
            Get
                Return mUserID
            End Get
            Set(ByVal value As Integer)
                mUserID = value
            End Set
        End Property

        Private mUser As User
        Public Overridable Property User() As User
            Get
                Return mUser
            End Get
            Set(ByVal value As User)
                mUser = value
            End Set
        End Property

    End Class
End Namespace
