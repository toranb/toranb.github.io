﻿Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Entity
Imports Persistence.BaseRepository
Imports NHibernate

Namespace DataAccess
    Public Class UserRepository
        Inherits NHibernateRepository(Of User)
        Implements IUserRepository

        Public Sub New()
            MyBase.New()
        End Sub

        Public Sub New(ByVal Session As ISession, ByVal Transaction As ITransaction)
            MyBase.New(Session, Transaction)
        End Sub

        Public Sub DeleteUser(ByVal User As User) Implements IUserRepository.DeleteUser
            MyBase.Delete(User)
        End Sub

        Public Function GetUserById(ByVal id As Integer) As User Implements IUserRepository.GetUserById
            Return MyBase.Retrieve(id)
        End Function

        Public Function GetUserCollection() As IQueryable(Of User) Implements IUserRepository.GetUserCollection
            Return MyBase.RetrieveAll()
        End Function

        Public Sub SaveUser(ByVal User As User) Implements IUserRepository.SaveUser
            MyBase.Save(User)
        End Sub

    End Class
End Namespace