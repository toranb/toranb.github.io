﻿Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Entity
Imports Persistence.BaseRepository
Imports NHibernate

Namespace DataAccess
    Public Class AccountRepository
        Inherits NHibernateRepository(Of Account)
        Implements IAccountRepository

        Public Sub New()
            MyBase.New()
        End Sub

        Public Sub New(ByVal Session As ISession, ByVal Transaction As ITransaction)
            MyBase.New(Session, Transaction)
        End Sub

        Public Sub DeleteAccount(ByVal Account As Account) Implements IAccountRepository.DeleteAccount
            MyBase.Delete(Account)
        End Sub

        Public Function GetAccountById(ByVal id As Integer) As Account Implements IAccountRepository.GetAccountById
            Return MyBase.Retrieve(id)
        End Function

        Public Function GetAccountCollection() As IQueryable(Of Account) Implements IAccountRepository.GetAccountCollection
            Return MyBase.RetrieveAll()
        End Function

        Public Sub SaveAccount(ByVal Account As Account) Implements IAccountRepository.SaveAccount
            MyBase.Save(Account)
        End Sub

    End Class
End Namespace