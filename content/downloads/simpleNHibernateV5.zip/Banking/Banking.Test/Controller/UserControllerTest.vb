﻿Imports System
Imports Banking
Imports System.Text
Imports System.Web.Mvc
Imports Banking.Library.Entity
Imports System.Collections.Generic
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Banking.Library.Service.Interfaces
Imports Rhino.Mocks

<TestClass()> _
Public Class UserControllerTest

    <TestMethod()> _
    Public Sub Should_Get_User_By_Id_And_Pass_Model_To_The_View()
        Dim Service As IUserService = MockRepository.GenerateStub(Of IUserService)()
        Dim Controller As UserController = New UserController(Service)

        Service.Stub(Function(x) x.GetUserById(1)).[Return](New User With {.ID = 1, .FirstName = "Toran", .LastName = "Billups", .Address = "1016 Cameron", .City = "Bondurant", .State = "IA", .Zip = "50035", .Phone = "5157795670"})

        Dim GetResult As ViewResult = Controller.Edit(1)

        Dim GetModel As User = DirectCast(GetResult.ViewData.Model, User)

        Assert.AreEqual(GetModel.ID, 1)
        Assert.AreEqual(GetModel.FirstName, "Toran")
        Assert.AreEqual(GetModel.LastName, "Billups")
        Assert.AreEqual(GetModel.Address, "1016 Cameron")
        Assert.AreEqual(GetModel.City, "Bondurant")
        Assert.AreEqual(GetModel.State, "IA")
        Assert.AreEqual(GetModel.Zip, "50035")
        Assert.AreEqual(GetModel.Phone, "5157795670")
    End Sub

End Class
