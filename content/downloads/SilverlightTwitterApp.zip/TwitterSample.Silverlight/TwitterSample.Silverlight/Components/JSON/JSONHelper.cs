﻿using System.IO;
using System.Runtime.Serialization;
using System.Text;

namespace TwitterSample.Silverlight.Components.JSON
{
    public class JSONHelper<T>
    {

        public static string ConvertObjectToJsonString(object input)
        {
            try
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    System.Runtime.Serialization.Json.DataContractJsonSerializer dataContractJsonSerializer = new System.Runtime.Serialization.Json.DataContractJsonSerializer(input.GetType());
                    dataContractJsonSerializer.WriteObject(memoryStream, input);
                    memoryStream.Position = 0;

                    using (StreamReader streamReader = new StreamReader(memoryStream))
                    {
                        return streamReader.ReadToEnd();
                    }
                }
            }
            catch (SerializationException generatedExceptionName)
            {
                return string.Empty;
            }
        }

        public static T ConvertJsonStringToObject(string json)
        {
            try
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    byte[] bytes = Encoding.Unicode.GetBytes(json);
                    memoryStream.Write(bytes, 0, bytes.Length);
                    memoryStream.Position = 0;

                    System.Runtime.Serialization.Json.DataContractJsonSerializer dataContractJsonSerializer = new System.Runtime.Serialization.Json.DataContractJsonSerializer(typeof(T));

                    return (T)dataContractJsonSerializer.ReadObject(memoryStream);
                }
            }
            catch (SerializationException generatedExceptionName)
            {
                throw generatedExceptionName;
            }
        }
    }
}
