﻿using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Net;
using System.IO;
using System.Threading;
using System.Net.Browser;
using System.Runtime.Serialization;
using System.Text;
using TwitterSample.Silverlight.Components.DTO;
using TwitterSample.Silverlight.Components.JSON;

namespace TwitterSample.Silverlight
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            Refresh.Click += new System.Windows.RoutedEventHandler(Refresh_Click);
            UpdateStatus.Click += new System.Windows.RoutedEventHandler(UpdateStatus_Click);

            RequestTimelineFromTwitterAPI();
        }

        void Refresh_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(() => RefreshTheTimeline());
        }

        void UpdateStatus_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(() => SetMessagePropertyBasedOnTextBoxValue());

            SubmitMessage();
        }

        public void RequestTimelineFromTwitterAPI()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequestCreator.ClientHttp.Create(new System.Uri("http://localhost:49170/Home/GetTimeline"));
            request.Method = "GET";

            request.BeginGetResponse(new AsyncCallback(TimelineRequestCompleted), request);
        }

        public void SubmitMessage()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequestCreator.ClientHttp.Create(new System.Uri("http://localhost:49170/Home/PostUpdate/"));
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";

            request.BeginGetRequestStream(new AsyncCallback(SendStatusUpdate), request);
        }

        public void SendStatusUpdate(IAsyncResult ar)
        {
            HttpWebRequest request = (HttpWebRequest)ar.AsyncState;

            Stream stream = request.EndGetRequestStream(ar);

            System.Text.UTF8Encoding data = new System.Text.UTF8Encoding();
            byte[] byteArray = data.GetBytes("status=" + StatusMessageValue);

            stream.Write(byteArray, 0, byteArray.Length);
            stream.Close();
            stream.Dispose();

            request.BeginGetResponse(new AsyncCallback(StatusUpdateCompleted), request);
        }

        public void StatusUpdateCompleted(IAsyncResult ar)
        {
            HttpWebRequest request = (HttpWebRequest)ar.AsyncState;

            HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(ar);

            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                string valid = reader.ReadToEnd();
            }
        }

        public void TimelineRequestCompleted(IAsyncResult ar)
        {
            HttpWebRequest request = (HttpWebRequest)ar.AsyncState;

            HttpWebResponse response = (HttpWebResponse)request.EndGetResponse(ar);

            string TwitterJSON;

            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                TwitterJSON = reader.ReadToEnd();
            }

            List<TwitterStatus> StatusCollection = JSONHelper<List<TwitterStatus>>.ConvertJsonStringToObject(TwitterJSON);

            this.Dispatcher.BeginInvoke(() => CallInvokeStuff(StatusCollection));
        }

        private object CallInvokeStuff(List<TwitterStatus> StatusCollection)
        {
            Tweeple.ItemsSource = StatusCollection;

            return null;
        }

        public object SetMessagePropertyBasedOnTextBoxValue()
        {
            string Status = StatusMessage.Text;

            StatusMessageValue = Status;

            StatusMessage.Text = "";

            return null;
        }

        public object RefreshTheTimeline()
        {
            RequestTimelineFromTwitterAPI();

            return null;
        }

        public string StatusMessageValue { get; set; }
    }
}
