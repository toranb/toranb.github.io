﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.IO;
using System.Xml;
using System.Web.Mvc;
using Components.DTO;
using Components.JSON;

namespace TwitterSample.Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public string GetTimeline()
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://twitter.com/statuses/friends_timeline.xml");
            request.Method = "GET";

            Byte[] authbytes = System.Text.UTF8Encoding.UTF8.GetBytes("username:password");
            request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(authbytes);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            string JSONString = ProcessStatusesAndReturnJSON(response.GetResponseStream());

            return JSONString;
        }

        private string ProcessStatusesAndReturnJSON(Stream str)
        {
            List<TwitterStatus> TwitterData = new List<TwitterStatus>();
            XmlDocument doc = new XmlDocument();
            doc.Load(str);
            XmlNodeList statuses = doc.SelectNodes("/statuses/status");

            foreach (XmlNode n in statuses)
            {
                TwitterData.Add(new TwitterStatus { Text = n.SelectSingleNode("text").InnerText, User = n.SelectSingleNode("user/screen_name").InnerText });
            }

            string JSONString = JSONHelper<List<TwitterStatus>>.ConvertObjectToJsonString(TwitterData);

            return JSONString;
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public bool PostUpdate(FormCollection collection)
        {
            string message = collection["status"];

            string user = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("username:password"));
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes("status=" + message);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://twitter.com/statuses/update.xml");
            request.Method = "POST";
            request.ServicePoint.Expect100Continue = false;
            request.Headers.Add("Authorization", "Basic " + user);
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = bytes.Length;

            Stream reqStream = request.GetRequestStream();
            reqStream.Write(bytes, 0, bytes.Length);
            reqStream.Close();
            reqStream.Dispose();

            return true;
        }
    }
}
