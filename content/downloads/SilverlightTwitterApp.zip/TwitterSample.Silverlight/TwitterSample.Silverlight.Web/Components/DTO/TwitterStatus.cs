﻿namespace Components.DTO
{
    public class TwitterStatus
    {
        public TwitterStatus() { }

        public string Text { get; set; }
        public string User { get; set; }
    }
}