Blog::Application.routes.draw do

  root :to => "welcome#index"

  devise_for :users

  get "welcome/index"

  resources :tags

  resources :posts do
    resources :comments
  end
end