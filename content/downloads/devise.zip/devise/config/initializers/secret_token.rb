# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = '14d00148b78e71ebf40b8ac4278e23b885d1e27b77c4ca5ac762a4724fa378b94780eaf425e150547d025cc8d73153e3d90e2b17cd5677eec6bc48d20b063b94'
