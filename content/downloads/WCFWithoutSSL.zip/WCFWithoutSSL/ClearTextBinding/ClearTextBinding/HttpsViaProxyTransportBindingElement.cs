﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.Text;

namespace CustomWCFBinding.BindingExtenions
{
    public class HttpsViaProxyTransportBindingElement : HttpTransportBindingElement, ITransportTokenAssertionProvider {
        public override T GetProperty<T>(BindingContext context) {
            if (typeof(T) == typeof(ISecurityCapabilities))
                return (T)(ISecurityCapabilities)new AutoSecuredHttpSecurityCapabilities();

            return base.GetProperty<T>(context);
        }

        public override BindingElement Clone() {
            return new HttpsViaProxyTransportBindingElement();
        }

        public System.Xml.XmlElement GetTransportTokenAssertion() {
            return null;
        }
    }
}
