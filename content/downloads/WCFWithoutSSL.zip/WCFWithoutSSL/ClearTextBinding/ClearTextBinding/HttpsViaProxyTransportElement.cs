﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using System.Text;

namespace CustomWCFBinding.BindingExtenions
{
    public class HttpsViaProxyTransportElement : HttpTransportElement {

        public override Type BindingElementType {
            get {
                return typeof(HttpsViaProxyTransportBindingElement);
            }
        }

        protected override TransportBindingElement CreateDefaultBindingElement() {
            return new HttpsViaProxyTransportBindingElement();
        }

    }
}