﻿Namespace Security.Encryption.QueryString
  ''' <summary>
  ''' Thrown when a queryString has expired and is therefore no longer valid.
  ''' </summary>
  Public Class ExpiredQueryStringException
    Inherits System.Exception
    Public Sub New()
      MyBase.New()
    End Sub
  End Class
End Namespace