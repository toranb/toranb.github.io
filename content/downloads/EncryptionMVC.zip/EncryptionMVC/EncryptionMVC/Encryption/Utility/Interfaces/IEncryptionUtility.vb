﻿Namespace Security.Encryption.Utility.Interfaces
  Public Interface IEncryptionUtility
    Function Decrypt(ByVal input As String) As String
    Function Encrypt(ByVal input As String) As String
    Function CombineBytes(ByVal buffer1 As Byte(), ByVal buffer2 As Byte()) As Byte()
  End Interface
End Namespace
