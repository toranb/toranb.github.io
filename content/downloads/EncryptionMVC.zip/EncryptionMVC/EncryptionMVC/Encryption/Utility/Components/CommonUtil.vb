﻿Namespace Security.Encryption.Utility.Components
  ''' <summary>
  ''' Utility class for common functions.
  ''' </summary>
  Public NotInheritable Class CommonUtil
    Private Sub New()
    End Sub

    ''' <summary>
    ''' Compares a set of byte arrays to determine if they are equal or not.
    ''' </summary>
    ''' <param name="array1">The first array to be compared.</param>
    ''' <param name="array2">The second array to be compared.</param>
    ''' <returns><c>true</c> if the byte arrays are of equal value. Otherwise <c>false</c>.</returns>
    Public Shared Function CompareBytes(ByVal array1 As Byte(), ByVal array2 As Byte()) As Boolean
      If array1.Length <> array2.Length Then
        Return False
      End If

      For i As Integer = 0 To array1.Length - 1
        If array1(i) <> array2(i) Then
          Return False
        End If
      Next
      Return True
    End Function
  End Class
End Namespace

