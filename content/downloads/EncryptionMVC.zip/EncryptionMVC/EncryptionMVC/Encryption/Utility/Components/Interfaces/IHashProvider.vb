﻿Namespace Security.Encryption.Utility.Components.Interfaces
  ''' <summary>
  ''' A contract for hashing functions used by a <see cref="SecureQueryString"/>.
  ''' </summary>
  Public Interface IHashProvider
    ''' <summary>
    ''' Computes the hash value from bytes.
    ''' </summary>
    ''' <param name="buffer">The buffer to hash.</param>
    ''' <returns>The computed hash.</returns>
    Function Hash(ByVal buffer As Byte()) As Byte()
  End Interface
End Namespace