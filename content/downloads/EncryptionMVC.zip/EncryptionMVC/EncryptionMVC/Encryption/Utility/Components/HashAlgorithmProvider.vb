﻿Imports System.Security.Cryptography
Imports EncryptionMVC.Security.Encryption.Utility.Components.Interfaces

Namespace Security.Encryption.Utility.Components
    ''' <summary>
    ''' Provides hash functions for any <see cref="HashAlgorithm"/>. By default,
    ''' this provider uses the <see cref="MD5"/> algorithm.
    ''' </summary>
    Public Class HashAlgorithmProvider
        Implements IHashProvider

        Private algorithm As HashAlgorithm

        ''' <summary>
        ''' Creates a default instance of this provider.
        ''' </summary>
        Public Sub New()
            Me.New(MD5CryptoServiceProvider.Create())
        End Sub

        ''' <summary>
        ''' Creates an instance with a specified hash algorithm.
        ''' </summary>
        ''' <param name="algorithm">The algorithm to use to compute the hash.</param>
        Public Sub New(ByVal algorithm As HashAlgorithm)
            Me.algorithm = algorithm
        End Sub

        ''' <summary>
        ''' Computes the hash value of a byte array using the specified algorithm.
        ''' </summary>
        ''' <param name="buffer">The buffer to hash.</param>
        ''' <returns>The computed hash.</returns>
        Public Function Hash(ByVal buffer() As Byte) As Byte() Implements IHashProvider.Hash
            Return algorithm.ComputeHash(buffer)
        End Function

    End Class
End Namespace

