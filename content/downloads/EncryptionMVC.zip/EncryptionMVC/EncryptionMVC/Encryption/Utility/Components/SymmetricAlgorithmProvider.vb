﻿Imports System.IO
Imports System.Security.Cryptography
Imports EncryptionMVC.Security.Encryption.Utility.Components.Interfaces

Namespace Security.Encryption.Utility.Components
    ''' <summary>
    ''' Provides cryptographic functions for any <see cref="SymmetricAlgorithm"/>.
    ''' By default, this provider uses the <see cref="RijndaelManaged"/> (AES) algorithm.
    ''' </summary>
    ''' <remarks>
    ''' The IV (Initialization Vector) is randomly generated and prepended to the resulting
    ''' ciphertext. This is because the IV ultimately uses the same distribution as the
    ''' ciphertext.
    ''' </remarks>
    Public Class SymmetricAlgorithmProvider
        Implements ISymmetricCryptoProvider

        Private IVSize As Integer
        Private algorithm As SymmetricAlgorithm

        ''' <summary>
        ''' Creates an instance using <see cref="RijndaelManaged"/> as the algorithm.
        ''' </summary>
        ''' <param name="key">The key to use for this algorithm.</param>
        Public Sub New(ByVal key As Byte())
            Me.New(RijndaelManaged.Create(), key)
        End Sub

        ''' <summary>
        ''' Creates an instance with a specified algorithm and key.
        ''' </summary>
        ''' <param name="algorithm">The algorithm to use for cryptographic functions.</param>
        ''' <param name="key">The key to use for this algorithm.</param>
        Public Sub New(ByVal algorithm As SymmetricAlgorithm, ByVal key As Byte())
            Me.algorithm = algorithm
            algorithm.Key = key
            algorithm.GenerateIV()
            IVSize = algorithm.IV.Length
        End Sub

        ''' <summary>
        ''' Encrypts a plaintext value.
        ''' </summary>
        ''' <param name="plaintext">The value to encrypt.</param>
        ''' <returns>The resulting ciphertext.</returns>
        Public Function Encrypt(ByVal plaintext As Byte()) As Byte() Implements ISymmetricCryptoProvider.Encrypt
            ValidateByteArrayParam("plaintext", plaintext)

            algorithm.GenerateIV()

            Dim ciphertext As Byte() = Nothing
            Using transform__1 As ICryptoTransform = DirectCast(algorithm.CreateEncryptor(), ICryptoTransform)
                ciphertext = Transform(transform__1, plaintext)
            End Using

            Return PrependIVToCipher(ciphertext)
        End Function

        ''' <summary>
        ''' Decrypts ciphertext.
        ''' </summary>
        ''' <param name="ciphertext">The ciphertext to decrypt.</param>
        ''' <returns>The resulting plaintext.</returns>
        Public Function Decrypt(ByVal ciphertext As Byte()) As Byte() Implements ISymmetricCryptoProvider.Decrypt
            ValidateByteArrayParam("ciphertext", ciphertext)

            algorithm.IV = GetIVFromCipher(ciphertext)

            Dim plaintext As Byte() = Nothing
            Using transform__1 As ICryptoTransform = DirectCast(algorithm.CreateDecryptor(), ICryptoTransform)
                plaintext = Transform(transform__1, StripIVFromCipher(ciphertext))
            End Using

            Return plaintext
        End Function

        Private Function Transform(ByVal transformation As ICryptoTransform, ByVal buffer As Byte()) As Byte()
            Dim returnBuffer As Byte() = Nothing

            Using stream As New MemoryStream()
                Dim cryptoStream As CryptoStream = Nothing
                Try
                    cryptoStream = New CryptoStream(stream, transformation, CryptoStreamMode.Write)
                    cryptoStream.Write(buffer, 0, buffer.Length)
                    cryptoStream.FlushFinalBlock()
                    returnBuffer = stream.ToArray()
                Finally
                    If cryptoStream IsNot Nothing Then
                        cryptoStream.Close()
                    End If
                End Try
            End Using

            Return returnBuffer
        End Function

        Private Sub ValidateByteArrayParam(ByVal paramName As String, ByVal value As Byte())
            If value Is Nothing OrElse value.Length = 0 Then
                Throw New ArgumentNullException(paramName)
            End If
        End Sub

        Private Function PrependIVToCipher(ByVal ciphertext As Byte()) As Byte()
            Dim buffer__1 As Byte() = New Byte(ciphertext.Length + (algorithm.IV.Length - 1)) {}
            Buffer.BlockCopy(algorithm.IV, 0, buffer__1, 0, algorithm.IV.Length)
            Buffer.BlockCopy(ciphertext, 0, buffer__1, algorithm.IV.Length, ciphertext.Length)

            Return buffer__1
        End Function

        Private Function GetIVFromCipher(ByVal ciphertext As Byte()) As Byte()
            Dim buffer__1 As Byte() = New Byte(IVSize - 1) {}
            Buffer.BlockCopy(ciphertext, 0, buffer__1, 0, IVSize)
            Return buffer__1
        End Function

        Private Function StripIVFromCipher(ByVal ciphertext As Byte()) As Byte()
            Dim buffer__1 As Byte() = New Byte(ciphertext.Length - IVSize - 1) {}
            Buffer.BlockCopy(ciphertext, IVSize, buffer__1, 0, buffer__1.Length)
            Return buffer__1
        End Function
    End Class
End Namespace

