﻿Namespace Security.Encryption.Utility.Components.Interfaces
  ''' <summary>
  ''' A contract for symmetric cryptographic functions used by a <see cref="SecureQueryString"/>.
  ''' </summary>
  ''' <remarks>
  ''' You may have noticed that this interface does not require a key. This is to support
  ''' "keyless" protection mechanisms such as DPAPI. Please review the implementation found
  ''' in <see cref="SymmetricAlgorithmProvider"/> to understand how to use keys.
  ''' </remarks>
  Public Interface ISymmetricCryptoProvider
    ''' <summary>
    ''' Encrypts a plaintext value.
    ''' </summary>
    ''' <param name="plaintext">The value to encrypt.</param>
    ''' <returns>The resulting ciphertext.</returns>
    Function Encrypt(ByVal plaintext As Byte()) As Byte()
    ''' <summary>
    ''' Decrypts ciphertext.
    ''' </summary>
    ''' <param name="ciphertext">The ciphertext to decrypt.</param>
    ''' <returns>The resulting plaintext.</returns>
    Function Decrypt(ByVal ciphertext As Byte()) As Byte()
  End Interface
End Namespace