﻿Imports System.IO
Imports System.Xml
Imports System.Text
Imports System.Security.Cryptography
Imports EncryptionMVC.Security.Encryption.Utility.Components.Interfaces
Imports EncryptionMVC.Security.Encryption.Utility.Interfaces
Imports EncryptionMVC.Security.Encryption.Utility.Components

Namespace Security.Encryption.Utility
  ''' <summary>
  ''' Provides a general encrypt and decrypt method, requires a 16 char key
  ''' </summary>
  Public Class EncryptionUtility
    Implements IEncryptionUtility

    Private key() As Byte = {}
    Private m_symmetricCryptoProvider As ISymmetricCryptoProvider
    Private m_hashProvider As IHashProvider

    ''' <summary>
    ''' Creates an instance with a specified key.
    ''' </summary>
    ''' <param name="key">The key used for cryptographic functions, required 16 chars in length.</param>
    Public Sub New(ByVal key As String)
      Me.key = System.Text.Encoding.UTF8.GetBytes(Left(key, 16))
      m_symmetricCryptoProvider = New SymmetricAlgorithmProvider(Me.key)
      m_hashProvider = New HashAlgorithmProvider()
    End Sub

    Public Function CombineBytes(ByVal buffer1() As Byte, ByVal buffer2() As Byte) As Byte() Implements IEncryptionUtility.CombineBytes
      Dim combinedBytes As Byte() = Nothing

      Try
        combinedBytes = New Byte(buffer1.Length + (buffer2.Length - 1)) {}
        Buffer.BlockCopy(buffer1, 0, combinedBytes, 0, buffer1.Length)
        Buffer.BlockCopy(buffer2, 0, combinedBytes, buffer1.Length, buffer2.Length)
      Catch generatedExceptionName As Exception
        Throw New ApplicationException("combine method failed")
      End Try

      Return combinedBytes
    End Function

    Public Function Decrypt(ByVal input As String) As String Implements IEncryptionUtility.Decrypt
      Dim plainText As Byte() = Nothing

      Try
        Dim inputBytes As Byte() = Convert.FromBase64String(input)

        Dim hashLength As Byte = inputBytes(0)
        Dim hash As Byte() = New Byte(hashLength - 1) {}
        Buffer.BlockCopy(inputBytes, 1, hash, 0, hashLength)
        Dim cipherText As Byte() = New Byte(inputBytes.Length - hashLength - 2) {}
        Buffer.BlockCopy(inputBytes, hashLength + 1, cipherText, 0, cipherText.Length)
        Dim compareHash As Byte() = m_hashProvider.Hash(CombineBytes(key, cipherText))

        If Not CommonUtil.CompareBytes(hash, compareHash) Then
          Throw New ApplicationException("input value was improperly signed or tampered with")
        End If

        plainText = m_symmetricCryptoProvider.Decrypt(cipherText)
      Catch generatedExceptionName As Exception
        Throw New ApplicationException("decrypt method failed")
      End Try

      Return Encoding.Unicode.GetString(plainText)
    End Function

    Public Function Encrypt(ByVal input As String) As String Implements IEncryptionUtility.Encrypt
      Dim hashLength As Byte() = Nothing
      Dim signedBytes As Byte() = Nothing

      Try
        Dim cipherText As Byte() = m_symmetricCryptoProvider.Encrypt(Encoding.Unicode.GetBytes(input))
        Dim hash As Byte() = m_hashProvider.Hash(CombineBytes(key, cipherText))
        signedBytes = CombineBytes(hash, cipherText)
        hashLength = New Byte() {CByte(hash.Length)}
      Catch generatedExceptionName As Exception
        Throw New ApplicationException("encrypt method failed")
      End Try

      Return Convert.ToBase64String(CombineBytes(hashLength, signedBytes))
    End Function
  End Class
End Namespace
