﻿Imports EncryptionMVC.Security.Encryption.QueryString

<HandleError()> _
Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Private mKey As String = "!#$a54?3!#$a54?3"

    Function Index() As ActionResult
        ViewData("Message") = "Welcome to ASP.NET MVC!"

        Return View()
    End Function

    <AcceptVerbs(HttpVerbs.Post)> _
    Function Index(ByVal collection As FormCollection) As ActionResult
        Dim qs As New SecureQueryString(mKey)

        qs("YourName") = collection("name")
        qs.ExpireTime = DateTime.Now.AddMinutes(2)

        Response.Redirect("Home.aspx/About?data=" + HttpUtility.UrlEncode(qs.ToString()))
    End Function

    Function About() As ActionResult
        If Request("data") IsNot Nothing Then
            Try
                Dim qs As New SecureQueryString(mKey, Request("data"))

                ViewData("Message") = "Your name is " + qs("YourName")
            Catch ex As Exception

            End Try
        End If

        Return View()
    End Function
End Class
