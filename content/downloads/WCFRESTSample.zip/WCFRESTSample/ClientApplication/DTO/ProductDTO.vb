﻿Namespace DTO
    Public Class ProductDTO

        Public Sub New()

        End Sub

        Private mID As Integer
        Public Property ID() As Integer
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mProductName As String
        Public Property ProductName() As String
            Get
                Return mProductName
            End Get
            Set(ByVal value As String)
                mProductName = value
            End Set
        End Property

        Private mQuantityPerUnit As String
        Public Property QuantityPerUnit() As String
            Get
                Return mQuantityPerUnit
            End Get
            Set(ByVal value As String)
                mQuantityPerUnit = value
            End Set
        End Property

        Private mUnitPrice As Nullable(Of Decimal)
        Public Property UnitPrice() As Nullable(Of Decimal)
            Get
                Return mUnitPrice
            End Get
            Set(ByVal value As Nullable(Of Decimal))
                mUnitPrice = value
            End Set
        End Property

        Private mUnitsInStock As Nullable(Of Integer)
        Public Property UnitsInStock() As Nullable(Of Integer)
            Get
                Return mUnitsInStock
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mUnitsInStock = value
            End Set
        End Property

        Private mUnitsOnOrder As Nullable(Of Integer)
        Public Property UnitsOnOrder() As Nullable(Of Integer)
            Get
                Return mUnitsOnOrder
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mUnitsOnOrder = value
            End Set
        End Property

        Private mReorderLevel As Nullable(Of Integer)
        Public Property ReorderLevel() As Nullable(Of Integer)
            Get
                Return mReorderLevel
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mReorderLevel = value
            End Set
        End Property

        Private mDiscontinued As Boolean
        Public Property Discontinued() As Boolean
            Get
                Return mDiscontinued
            End Get
            Set(ByVal value As Boolean)
                mDiscontinued = value
            End Set
        End Property

    End Class
End Namespace
