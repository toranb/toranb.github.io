﻿var lastSelectedItem;
var timer;
var rootURL = getRootURL();
//
// Product Specific JS
//
function ToggleProductDetails(obj, id) {
    obj.blur();

    if (lastSelectedItem == id) {
        collapseDetails(obj);
    } else {
        if ($("#detailTR").get(0)) {
            collapseDetails(obj);
        }
        GetProductDetails(obj, id);
    }
}
function GetProductDetails(obj, id) {
    $.ajax({
        type: "GET",
        url: rootURL + "Home.aspx/ProductDetail/" + id,
        dataType: "html",
        beforeSend: function() { lastSelectedItem = id; },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.responseText);
        },
        success: function(xhtml) {
            $("<tr id='detailTR'><td colSpan='7'><div id='fillDiv'></div></td></tr>").insertAfter($(obj).parent().parent());

            $("#fillDiv").html(xhtml);
        }
    });
}
function UpdateProductDetails(obj, id) {
    obj.blur();

    $("#lblUpdateStatus").text("");

    var ProductName = $("#ProductName").val();
    var QuantityPerUnit = $("#QuantityPerUnit").val();
    var UnitPrice = $("#UnitPrice").val();
    var UnitsInStock = $("#UnitsInStock").val();
    var UnitsOnOrder = $("#UnitsOnOrder").val();
    var ReorderLevel = $("#ReorderLevel").val();
    var Discontinued = $("#Discontinued").val();

    var info = { ProductName: ProductName, QuantityPerUnit: QuantityPerUnit, UnitPrice: UnitPrice, UnitsInStock: UnitsInStock, UnitsOnOrder: UnitsOnOrder, ReorderLevel: ReorderLevel, Discontinued: Discontinued };

    $.ajax({
        type: "POST",
        url: rootURL + "Home.aspx/UpdateProduct/" + id,
        data: info,
        dataType: "xml",
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.responseText);
        },
        success: function(xml) {
            var UpdatedProductName = $("#ProductName").val();

            var prevTR = $(obj).parent().parent().parent().parent().parent().parent().parent().prev();

            prevTR.find("a.link").text(UpdatedProductName);

            $("#lblUpdateStatus").css("color", "green").text("Saved");

            prevTR.highlightFade({ color: 'rgb(255,255,0)', iterator: 'sinusoidal' });

            clearTimeout(timer);
            timer = window.setTimeout(function() { $("#lblUpdateStatus").text(""); }, 5000);
        }
    });
}
function collapseDetails(obj) {
    if ($("#detailTR").get(0)) {
        $("#detailTR").remove();
        lastSelectedItem = null;
    }
}
function getRootURL() {
    var baseURL = location.href;
    var rootURL = baseURL.substring(0, baseURL.indexOf('/', 7));

    // if the root url is localhost, don't add the directory as cassani doesn't use it
    if (baseURL.indexOf('localhost') == -1) {
        return rootURL + "/ClientApplication/";
    } else {
        return rootURL + "/";
    }
}