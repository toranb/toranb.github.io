﻿Imports System.Net
Imports System.IO
Imports System.Runtime.Serialization

Public Class JSONHelper(Of T)

    Public Shared Function ConvertObjectToJsonString(ByVal input As Object) As String
        Try
            Using memoryStream As New MemoryStream()

                Dim dataContractJsonSerializer As New Runtime.Serialization.Json.DataContractJsonSerializer(input.[GetType]())
                dataContractJsonSerializer.WriteObject(memoryStream, input)
                memoryStream.Position = 0

                Using streamReader As New StreamReader(memoryStream)
                    Return streamReader.ReadToEnd()
                End Using
            End Using
        Catch generatedExceptionName As SerializationException
            Return String.Empty
        End Try
    End Function

    Public Shared Function ConvertJsonStringToObject(ByVal json As String) As T
        Try
            Using memoryStream As New MemoryStream()
                Dim bytes As Byte() = Encoding.Unicode.GetBytes(json)
                memoryStream.Write(bytes, 0, bytes.Length)
                memoryStream.Position = 0

                Dim dataContractJsonSerializer As New Runtime.Serialization.Json.DataContractJsonSerializer(GetType(T))

                Return DirectCast(dataContractJsonSerializer.ReadObject(memoryStream), T)
            End Using
        Catch generatedExceptionName As SerializationException
            Return Nothing
        End Try
    End Function
End Class