﻿Imports ClientApplication.DTO
Imports System.Net
Imports System.IO
Imports System.Runtime.Serialization

<HandleError()> _
Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Function Index() As ActionResult
        Return View()
    End Function

    Function About() As ActionResult
        Return View()
    End Function

    Function Products() As ActionResult
        Dim ProductList As List(Of ProductDTO)
        Dim JSONString As String

        Dim request As HttpWebRequest = WebRequest.Create("http://localhost:63770/ProductService.svc/products/")
        request.Method = "GET"

        Dim response As HttpWebResponse = request.GetResponse()

        Using reader As StreamReader = New StreamReader(response.GetResponseStream())
            JSONString = reader.ReadToEnd()
        End Using

        ProductList = JSONHelper(Of List(Of ProductDTO)).ConvertJsonStringToObject(JSONString)

        Return View(ProductList)
    End Function

    Function ProductDetail(ByVal id As Integer) As ActionResult
        Dim Product As ProductDTO
        Dim JSONString As String

        Dim request As HttpWebRequest = WebRequest.Create("http://localhost:63770/ProductService.svc/products/" + id.ToString())
        request.Method = "GET"

        Dim response As HttpWebResponse = request.GetResponse()

        Using reader As StreamReader = New StreamReader(response.GetResponseStream())
            JSONString = reader.ReadToEnd()
        End Using

        Product = JSONHelper(Of ProductDTO).ConvertJsonStringToObject(JSONString)

        Return PartialView("ProductDetail", Product)
    End Function

    <AcceptVerbs(HttpVerbs.Post)> _
    Function UpdateProduct(ByVal id As Integer, ByVal collection As FormCollection) As ActionResult
        Dim ReturnXML As String = "<data><valid>false</valid></data>"

        Dim Product As New ProductDTO()
        Dim JSONString As String

        Product.ID = id
        Product.ProductName = collection("ProductName")
        Product.QuantityPerUnit = collection("QuantityPerUnit")
        Product.UnitPrice = collection("UnitPrice")
        Product.UnitsInStock = collection("UnitsInStock")
        Product.UnitsOnOrder = collection("UnitsOnOrder")
        Product.ReorderLevel = collection("ReorderLevel")
        Product.Discontinued = collection("Discontinued")

        JSONString = JSONHelper(Of ProductDTO).ConvertObjectToJsonString(Product)

        Dim request As HttpWebRequest = WebRequest.Create("http://localhost:63770/ProductService.svc/products/" + id.ToString())
        request.Method = "PUT"

        Dim response As HttpWebResponse
        request.ContentType = "application/x-www-form-urlencoded"

        Dim data As New System.Text.UTF8Encoding

        Dim byteArray As Byte() = data.GetBytes(JSONString)

        request.ContentLength = byteArray.Length

        Dim requestStream As System.IO.Stream = request.GetRequestStream()
        requestStream.Write(byteArray, 0, byteArray.Length)

        requestStream.Close()
        requestStream.Dispose()
        request.AllowAutoRedirect = True
        response = CType(request.GetResponse(), HttpWebResponse)

        If response.StatusCode = HttpStatusCode.OK Then
            ReturnXML = "<data><valid>true</valid></data>"
        End If

        Return Me.Content(ReturnXML, "text/xml")
    End Function
End Class
