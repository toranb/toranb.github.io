﻿Imports RESTWCFWebService.Library.DataAccess.Interfaces
Imports RESTWCFWebService.Library.Entity

Namespace DataAccess
    Public Class ProductRepository
        Implements IProductRepository

        Public Sub ClearProductCollection() Implements Interfaces.IProductRepository.ClearProductCollection

        End Sub

        Public Sub DeleteProductByID(ByVal id As Integer) Implements Interfaces.IProductRepository.DeleteProductByID

        End Sub

        Public Function GetProductById(ByVal id As Integer) As Entity.Product Implements Interfaces.IProductRepository.GetProductById
            Return New Product With {.ID = 1, .Discontinued = False, .ProductName = "Chai", .QuantityPerUnit = "10 boxes", .ReorderLevel = 20, .UnitPrice = 20.0, .UnitsInStock = 10, .UnitsOnOrder = 1}
        End Function

        Public Function GetProductCollection() As System.Collections.Generic.IEnumerable(Of Entity.Product) Implements Interfaces.IProductRepository.GetProductCollection
            Dim ProductCollection As New List(Of Product)

            ProductCollection.Add(New Product With {.ID = 1, .ProductName = "Chai", .QuantityPerUnit = "10 boxes x 20 bags", .UnitPrice = 18.0, .UnitsInStock = 39, .UnitsOnOrder = 0, .ReorderLevel = 10, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 2, .ProductName = "Chang", .QuantityPerUnit = "24 - 12 oz bottles", .UnitPrice = 34.0, .UnitsInStock = 22, .UnitsOnOrder = 40, .ReorderLevel = 20, .Discontinued = True})
            ProductCollection.Add(New Product With {.ID = 3, .ProductName = "Aniseed Syrup", .QuantityPerUnit = "12 - 550 ml bottles", .UnitPrice = 89.0, .UnitsInStock = 78, .UnitsOnOrder = 70, .ReorderLevel = 30, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 4, .ProductName = "Chef Anton's Cajun Seasoning", .QuantityPerUnit = "48 - 6 oz jars", .UnitPrice = 99.0, .UnitsInStock = 18, .UnitsOnOrder = 64, .ReorderLevel = 40, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 5, .ProductName = "Chef Anton's Gumbo Mix", .QuantityPerUnit = "36 boxes", .UnitPrice = 13.0, .UnitsInStock = 90, .UnitsOnOrder = 10, .ReorderLevel = 50, .Discontinued = False})

            Return ProductCollection
        End Function

        Public Sub SaveProduct(ByVal ProductObject As Entity.Product) Implements Interfaces.IProductRepository.SaveProduct

        End Sub
    End Class
End Namespace