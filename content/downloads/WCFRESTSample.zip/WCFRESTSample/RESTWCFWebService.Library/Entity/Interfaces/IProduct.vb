﻿Imports RESTWCFWebService.Library.Entity

Namespace Entity.Interfaces
  Interface IProduct
    Property ID() As Integer
    Property ProductName() As String
    Property QuantityPerUnit() As String
    Property UnitPrice() As Nullable(Of Decimal)
    Property UnitsInStock() As Nullable(Of Integer)
    Property UnitsOnOrder() As Nullable(Of Integer)
    Property ReorderLevel() As Nullable(Of Integer)
    Property Discontinued() As Boolean
  End Interface
End Namespace
