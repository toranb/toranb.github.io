﻿Imports RESTWCFWebService.Library.Entity.Interfaces

Namespace Entity
    Public Class Product
        Implements IProduct

        Public Sub New()

        End Sub

        Public Sub New(ByVal ID As Integer, ByVal ProductName As String, ByVal QuantityPerUnit As String, ByVal UnitPrice As Nullable(Of Decimal), ByVal UnitsInStock As Nullable(Of Integer), ByVal UnitsOnOrder As Nullable(Of Integer), ByVal ReorderLevel As Nullable(Of Integer), ByVal Discontinued As Boolean)
            mID = ID
            mProductName = ProductName
            mQuantityPerUnit = QuantityPerUnit
            mUnitPrice = UnitPrice
            mUnitsInStock = UnitsInStock
            mUnitsOnOrder = UnitsOnOrder
            mReorderLevel = ReorderLevel
            mDiscontinued = Discontinued
        End Sub

        Private mID As Integer
        Public Property ID() As Integer Implements IProduct.ID
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mProductName As String
        Public Property ProductName() As String Implements IProduct.ProductName
            Get
                Return mProductName
            End Get
            Set(ByVal value As String)
                mProductName = value
            End Set
        End Property

        Private mQuantityPerUnit As String
        Public Property QuantityPerUnit() As String Implements IProduct.QuantityPerUnit
            Get
                Return mQuantityPerUnit
            End Get
            Set(ByVal value As String)
                mQuantityPerUnit = value
            End Set
        End Property

        Private mUnitPrice As Nullable(Of Decimal)
        Public Property UnitPrice() As Nullable(Of Decimal) Implements IProduct.UnitPrice
            Get
                Return mUnitPrice
            End Get
            Set(ByVal value As Nullable(Of Decimal))
                mUnitPrice = value
            End Set
        End Property

        Private mUnitsInStock As Nullable(Of Integer)
        Public Property UnitsInStock() As Nullable(Of Integer) Implements IProduct.UnitsInStock
            Get
                Return mUnitsInStock
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mUnitsInStock = value
            End Set
        End Property

        Private mUnitsOnOrder As Nullable(Of Integer)
        Public Property UnitsOnOrder() As Nullable(Of Integer) Implements IProduct.UnitsOnOrder
            Get
                Return mUnitsOnOrder
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mUnitsOnOrder = value
            End Set
        End Property

        Private mReorderLevel As Nullable(Of Integer)
        Public Property ReorderLevel() As Nullable(Of Integer) Implements IProduct.ReorderLevel
            Get
                Return mReorderLevel
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mReorderLevel = value
            End Set
        End Property

        Private mDiscontinued As Boolean
        Public Property Discontinued() As Boolean Implements IProduct.Discontinued
            Get
                Return mDiscontinued
            End Get
            Set(ByVal value As Boolean)
                mDiscontinued = value
            End Set
        End Property

    End Class
End Namespace
