﻿Imports RESTWCFWebService.Library.Entity
Imports System.ServiceModel
Imports System.ServiceModel.Web

Namespace Service.Interfaces
    <ServiceContract()> _
        Public Interface IProductService
        <OperationContract()> _
        <WebGet(UriTemplate:="/products/", BodyStyle:=WebMessageBodyStyle.Bare, ResponseFormat:=WebMessageFormat.Json)> _
        Function GetProductCollection() As List(Of Product)

        <OperationContract()> _
        <WebGet(UriTemplate:="/products/{id}", BodyStyle:=WebMessageBodyStyle.Bare, ResponseFormat:=WebMessageFormat.Json)> _
        Function GetProductById(ByVal id As String) As Product

        <OperationContract()> _
        <WebInvoke(Method:="PUT", UriTemplate:="/products/{id}")> _
        Sub SaveProduct(ByVal id As String, ByVal data As System.IO.Stream)

        <OperationContract()> _
        <WebInvoke(Method:="DELETE", UriTemplate:="/products/{id}")> _
        Sub DeleteProductByID(ByVal id As String)
    End Interface
End Namespace
