﻿Imports RESTWCFWebService.Library.DataAccess
Imports RESTWCFWebService.Library.Entity
Imports RESTWCFWebService.Library.DataAccess.Interfaces
Imports RESTWCFWebService.Library.Service.Interfaces
Imports System.IO

Namespace Service
    Public Class ProductService
        Implements IProductService

        Private mRepository As IProductRepository

        Public Sub New()
            Me.New(New ProductRepository())
        End Sub

        Public Sub New(ByVal Repository As IProductRepository)
            mRepository = Repository
        End Sub

        Public Function GetProductCollection() As List(Of Product) Implements IProductService.GetProductCollection
            Return mRepository.GetProductCollection()
        End Function

        Public Function GetProductById(ByVal id As String) As Entity.Product Implements IProductService.GetProductById
            Return mRepository.GetProductById(id)
        End Function

        Public Sub DeleteProductByID(ByVal id As String) Implements IProductService.DeleteProductByID
            mRepository.DeleteProductByID(id)
        End Sub

        Public Sub SaveProduct(ByVal id As String, ByVal data As System.IO.Stream) Implements IProductService.SaveProduct
            Dim ProductObject As Product
            Dim ProductJSON As String

            Using reader As StreamReader = New StreamReader(data)
                ProductJSON = reader.ReadToEnd()
            End Using

            ProductObject = JSONHelper(Of Product).ConvertJsonStringToObject(ProductJSON)

            mRepository.SaveProduct(ProductObject)
        End Sub
    End Class
End Namespace