﻿/// <reference path="jquery-1.3.1-vsdoc.js" />
var lastSelectedItem;
var timer;
//
// Product Specific JS
//
function ToggleProductDetails(obj, id) {
    obj.blur();

    if (lastSelectedItem == id) {
        collapseDetails(obj);
    } else {
        if ($("#detailTR").get(0)) {
            collapseDetails(obj);
        }
        GetProductDetails(obj, id);
    }
}
function GetProductDetails(obj, id) {
    $.ajax({
        type: "GET",
        url: "ProductDetailsView.aspx?id=" + id,
        dataType: "html",
        beforeSend: function() { lastSelectedItem = id; },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.responseText);
        },
        success: function(xhtml) {
            $("<tr id='detailTR'><td colSpan='3'><div id='fillDiv'></div></td></tr>").insertAfter($(obj).parent().parent());

            $("#fillDiv").html(xhtml);

            //cleanup the html from asp.net quick
            removeExtraFormData($("#fillDiv"));
        }
    });
}
function UpdateProductDetails(obj) {
    obj.blur();

    $("#lblUpdateStatus").text("");

    var ProductName = $("#txtProductName").val();
    var QuantityPerUnit = $("#txtQuantityPerUnit").val();
    var UnitPrice = $("#txtUnitPrice").val();
    var UnitsInStock = $("#txtUnitsInStock").val();
    var UnitsOnOrder = $("#txtUnitsOnOrder").val();
    var ReorderLevel = $("#txtReorderLevel").val();
    var Discontinued = $("#txtDiscontinued").val();
    var Supplier = $("#ddlSupplier").attr('selectedIndex');
    var Category = $("#ddlCategory").attr('selectedIndex');

    var info = { ProductName: ProductName, QuantityPerUnit: QuantityPerUnit, UnitPrice: UnitPrice, UnitsInStock: UnitsInStock, UnitsOnOrder: UnitsOnOrder, ReorderLevel: ReorderLevel, Discontinued: Discontinued, Supplier: Supplier, Category: Category };

    $.ajax({
        type: "POST",
        url: obj.href,
        data: info,
        dataType: "xml",
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.responseText);
        },
        success: function(xml) {
            var UpdatedProductName = $("#txtProductName").val();

            var prevTR = $(obj).parent().parent().parent().parent().parent().prev();

            prevTR.find("a.link").text(UpdatedProductName);

            $("#lblUpdateStatus").css("color", "green").text("Saved");

            prevTR.highlightFade({ color: 'rgb(255,255,0)', iterator: 'sinusoidal' });

            clearTimeout(timer);
            timer = window.setTimeout(function() { $("#lblUpdateStatus").text(""); }, 5000);
        }
    });
}
function removeExtraFormData(parentObj) {
    $('form:eq(1)').children().each(
        function() {
            if ($('form:eq(1)').find('div').filter(function() { return $(this).attr('id') == ''; }).remove());
        }
    );

    //Capture the remaining children
    var children = $('form:eq(1)').children();

    // Remove the form
    $('form:eq(1)').remove();

    // append the correct child element back to the DOM
    parentObj.append(children);
}
function collapseDetails(obj) {
    if ($("#detailTR").get(0)) {
        $("#detailTR").remove();
        lastSelectedItem = null;
    }
}