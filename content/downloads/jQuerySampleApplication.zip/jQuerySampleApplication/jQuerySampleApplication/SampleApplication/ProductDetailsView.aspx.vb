﻿Imports SampleApplication.Entity

Partial Public Class ProductDetailsView
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Dim ProductID As Integer

        If Request.HttpMethod = "GET" Then
            ProductID = Request.QueryString("id")
            GetProductById(ProductID)

            lnkUpdate.HRef = "ProductDetailsView.aspx?id=" + ProductID.ToString()
        ElseIf Request.HttpMethod = "POST" Then
            Response.ContentType = "text/xml"
            Response.Write("<data><valid>true</valid></data>")
            Response.End()
        Else
            Response.StatusCode = 404
            Response.End()
        End If
    End Sub

    Public Sub GetProductById(ByVal id As Integer)
        Dim ProductObject As Product

        If id > 0 Then
            ProductObject = SetupProductBasedOnProductID(id)
        End If

        If ProductObject IsNot Nothing Then
            txtProductName.Value = ProductObject.ProductName
            txtQuantityPerUnit.Value = ProductObject.QuantityPerUnit
            txtUnitPrice.Value = ProductObject.UnitPrice
            txtUnitsInStock.Value = ProductObject.UnitsInStock
            txtUnitsOnOrder.Value = ProductObject.UnitsOnOrder
            txtReorderLevel.Value = ProductObject.ReorderLevel
            txtDiscontinued.Value = ProductObject.Discontinued
        End If
    End Sub

    Private Function SetupProductBasedOnProductID(ByVal id As Integer) As Product
        If id = 1 Then
            Return New Product With {.ID = 1, .ProductName = "Chai", .QuantityPerUnit = "10 boxes x 20 bags", .UnitPrice = 18.0, .UnitsInStock = 39, .UnitsOnOrder = 0, .ReorderLevel = 10, .Discontinued = False}
        ElseIf id = 2 Then
            Return New Product With {.ID = 2, .ProductName = "Chang", .QuantityPerUnit = "24 - 12 oz bottles", .UnitPrice = 34.0, .UnitsInStock = 22, .UnitsOnOrder = 40, .ReorderLevel = 20, .Discontinued = True}
        Else
            Return New Product With {.ID = 3, .ProductName = "Aniseed Syrup", .QuantityPerUnit = "12 - 550 ml bottles", .UnitPrice = 89.0, .UnitsInStock = 78, .UnitsOnOrder = 70, .ReorderLevel = 30, .Discontinued = False}
        End If
    End Function

End Class

