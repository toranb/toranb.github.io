﻿Imports SampleApplication.Entity

Partial Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim ProductCollection As New List(Of Product)

            ProductCollection.Add(New Product With {.ID = 1, .ProductName = "Chai", .QuantityPerUnit = "10 boxes x 20 bags", .UnitPrice = 18.0, .UnitsInStock = 39, .UnitsOnOrder = 0, .ReorderLevel = 10, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 2, .ProductName = "Chang", .QuantityPerUnit = "24 - 12 oz bottles", .UnitPrice = 34.0, .UnitsInStock = 22, .UnitsOnOrder = 40, .ReorderLevel = 20, .Discontinued = True})
            ProductCollection.Add(New Product With {.ID = 3, .ProductName = "Aniseed Syrup", .QuantityPerUnit = "12 - 550 ml bottles", .UnitPrice = 89.0, .UnitsInStock = 78, .UnitsOnOrder = 70, .ReorderLevel = 30, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 4, .ProductName = "Chef Anton's Cajun Seasoning", .QuantityPerUnit = "48 - 6 oz jars", .UnitPrice = 99.0, .UnitsInStock = 18, .UnitsOnOrder = 64, .ReorderLevel = 40, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 5, .ProductName = "Chef Anton's Gumbo Mix", .QuantityPerUnit = "36 boxes", .UnitPrice = 13.0, .UnitsInStock = 90, .UnitsOnOrder = 10, .ReorderLevel = 50, .Discontinued = False})

            gridProducts.DataSource = ProductCollection
            gridProducts.DataBind()
        End If
    End Sub

    Protected Sub gridSuppliers_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gridProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells((IIf(ViewState("PreviousHeaderIndex") Is Nothing, 0, CInt(ViewState("PreviousHeaderIndex"))))).CssClass += (IIf(DirectCast(ViewState("PreviousSortDirection"), String) = "Ascending", " sortasc", " sortdesc"))
            Return
        ElseIf e.Row.RowType <> DataControlRowType.DataRow Then
            Return
        End If

        Dim ProductObject As Product = DirectCast(e.Row.DataItem, Product)

        Dim lnkProductName As HtmlAnchor = DirectCast(e.Row.FindControl("lnkProductName"), HtmlAnchor)
        Dim lblQuantityPerUnit As HtmlContainerControl = DirectCast(e.Row.FindControl("lblQuantityPerUnit"), HtmlContainerControl)
        Dim lblUnitsInStock As HtmlContainerControl = DirectCast(e.Row.FindControl("lblUnitsInStock"), HtmlContainerControl)

        lnkProductName.InnerHtml = ProductObject.ProductName
        lnkProductName.HRef = "ProductDetailsView.aspx?id=" + ProductObject.ID.ToString()
        lnkProductName.Attributes.Add("onclick", "ToggleProductDetails(this, " + ProductObject.ID.ToString() + "); return false;")
        lblQuantityPerUnit.InnerHtml = ProductObject.QuantityPerUnit.ToString()
        lblUnitsInStock.InnerHtml = ProductObject.UnitsInStock.ToString()
    End Sub

End Class