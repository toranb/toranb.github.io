﻿Imports System.IO
Imports System.Linq
Imports System.Linq.Dynamic
Imports System.Web
Imports System.Web.Mvc

Public MustInherit Class JQGridHelperBase
    Inherits System.Web.Mvc.Controller

    Public Sub New()

    End Sub

    Public Function ProcessThePagingAndSortingRequest(ByVal collection As IEnumerable, ByVal sidx As String, ByVal sord As String, ByVal page As Integer, ByVal rows As Integer) As ActionResult
        Dim Search, SearchField, SearchOper, SearchString

        If collection IsNot Nothing Then
            If Request.QueryString("_search") = "true" Then
                Search = True
                SearchField = Request.QueryString("searchField")
                SearchOper = Request.QueryString("searchOper")
                SearchString = Request.QueryString("searchString")
            End If

            Return SortAndPageResults(collection, sidx, sord, page, rows, Search, SearchField, SearchOper, SearchString)
        End If

        Return Nothing
    End Function

    Public Function SortAndPageResults(ByVal collection As IEnumerable, ByVal sidx As String, ByVal sord As String, ByVal page As Integer, ByVal rows As Integer, ByVal search As Boolean, ByVal searchField As String, ByVal searchOper As String, ByVal searchString As String) As ActionResult
        Dim pageIndex As Integer = Convert.ToInt32(page) - 1
        Dim pageSize As Integer = rows
        Dim totalRecords As Integer = collection.AsQueryable.Count
        Dim totalPages As Integer = CInt(Math.Ceiling(CSng(totalRecords) / CSng(pageSize)))
        Dim FilteredAndSortedList

        If search = True Then
            Const strpredicateFormat As String = "{0}.ToString().StartsWith(@0)"
            Dim searchExpression = New System.Text.StringBuilder()
            Dim orPart As String = [String].Empty

            searchExpression.Append(orPart)
            searchExpression.AppendFormat(strpredicateFormat, searchField, searchString)

            FilteredAndSortedList = collection.AsQueryable().Where(searchExpression.ToString(), searchString)
        Else
            FilteredAndSortedList = collection.AsQueryable().OrderBy(sidx + " " + sord).Skip(pageIndex * pageSize).Take(pageSize)
        End If

        Dim jsonData = New With { _
            .total = totalPages, _
            .page = page, _
            .records = totalRecords, _
            .rows = BuildJSON(FilteredAndSortedList) _
        }

        Return Json(jsonData)
    End Function

    Public MustOverride Function BuildJSON(ByVal collection As IEnumerable) As Object

    Public Function GetArray(Of T)(ByVal ParamArray values() As T) As T()
        Return values
    End Function
End Class