﻿Imports JQGridSample.Entity
Imports System.IO
Imports System.Linq
Imports System.Linq.Dynamic

<HandleError()> _
Public Class HomeController
    Inherits JQGridHelperBase

    Function Index() As ActionResult
        ViewData("Message") = "Welcome to ASP.NET MVC!"

        Return View()
    End Function

    Function GetUserList(ByVal sidx As String, ByVal sord As String, ByVal page As Integer, ByVal rows As Integer) As ActionResult
        Dim UserCollection As IEnumerable(Of User) = SetupFakeUserCollection()

        Dim json As JsonResult = MyBase.ProcessThePagingAndSortingRequest(UserCollection, sidx, sord, page, rows)

        If json IsNot Nothing Then
            Return json
        End If

        Return Me.Content("{'total':0,'page':1,'records':0,'rows':[]}", "text/json")
    End Function

    Function SetupFakeUserCollection() As IEnumerable(Of User)
        Dim UserCollection As New List(Of User)

        For i = 0 To 100
            UserCollection.Add(New User With {.ID = i, .FirstName = "John", .LastName = "Doe", .Address = "400 SW 8th", .City = "Des Moines", .State = "IA", .Zip = "50309", .Phone = "5152843369"})
        Next

        Return UserCollection
    End Function

    Public Overrides Function BuildJSON(ByVal collection As System.Collections.IEnumerable) As Object
        If collection Is Nothing Then
            Return Nothing
        End If

        Dim values(collection.AsQueryable.Count() - 1)

        For i = 0 To collection.AsQueryable.Count - 1
            values(i) = New With {.id = collection(i).ID, .cell = MyBase.GetArray(collection(i).ID.ToString(), collection(i).FirstName, collection(i).LastName, collection(i).Address, collection(i).City, collection(i).State, collection(i).Zip, collection(i).Phone)}
        Next

        Return values
    End Function
End Class
