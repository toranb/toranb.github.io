﻿Namespace Entity
    Public Class User

        Public Sub New()

        End Sub

        Public Sub New(ByVal ID As Integer, ByVal FirstName As String, ByVal LastName As String, ByVal Address As String, ByVal City As String, ByVal State As String, ByVal Zip As String, ByVal Phone As String)
            mID = ID
            mFirstName = FirstName
            mLastName = LastName
            mAddress = Address
            mCity = City
            mState = State
            mZip = Zip
            mPhone = Phone
        End Sub

        Private mID As Integer
        Public Overridable Property ID() As Integer
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mFirstName As String
        Public Overridable Property FirstName() As String
            Get
                Return mFirstName
            End Get
            Set(ByVal value As String)
                mFirstName = value
            End Set
        End Property

        Private mLastName As String
        Public Overridable Property LastName() As String
            Get
                Return mLastName
            End Get
            Set(ByVal value As String)
                mLastName = value
            End Set
        End Property

        Private mAddress As String
        Public Overridable Property Address() As String
            Get
                Return mAddress
            End Get
            Set(ByVal value As String)
                mAddress = value
            End Set
        End Property

        Private mCity As String
        Public Overridable Property City() As String
            Get
                Return mCity
            End Get
            Set(ByVal value As String)
                mCity = value
            End Set
        End Property

        Private mState As String
        Public Overridable Property State() As String
            Get
                Return mState
            End Get
            Set(ByVal value As String)
                mState = value
            End Set
        End Property

        Private mZip As String
        Public Overridable Property Zip() As String
            Get
                Return mZip
            End Get
            Set(ByVal value As String)
                mZip = value
            End Set
        End Property

        Private mPhone As String
        Public Overridable Property Phone() As String
            Get
                Return mPhone
            End Get
            Set(ByVal value As String)
                mPhone = value
            End Set
        End Property

    End Class
End Namespace
