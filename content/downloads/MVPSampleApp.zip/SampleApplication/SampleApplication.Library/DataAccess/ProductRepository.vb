﻿Imports SampleApplication.Library.DataAccess.Interfaces
Imports SampleApplication.Library.Entity

Namespace DataAccess
    Public Class ProductRepository
        Implements IProductRepository

        Public Sub New()

        End Sub

        Public Function GetProductCollection() As IEnumerable(Of Product) Implements IProductRepository.GetProductCollection
            Dim ProductCollection As New List(Of Product)

            ProductCollection.Add(New Product With {.ID = 1, .ProductName = "Chai", .QuantityPerUnit = "10 boxes x 20 bags", .UnitPrice = 18.0, .UnitsInStock = 39, .UnitsOnOrder = 0, .ReorderLevel = 10, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 2, .ProductName = "Chang", .QuantityPerUnit = "24 - 12 oz bottles", .UnitPrice = 34.0, .UnitsInStock = 22, .UnitsOnOrder = 40, .ReorderLevel = 20, .Discontinued = True})
            ProductCollection.Add(New Product With {.ID = 3, .ProductName = "Aniseed Syrup", .QuantityPerUnit = "12 - 550 ml bottles", .UnitPrice = 89.0, .UnitsInStock = 78, .UnitsOnOrder = 70, .ReorderLevel = 30, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 4, .ProductName = "Chef Anton's Cajun Seasoning", .QuantityPerUnit = "48 - 6 oz jars", .UnitPrice = 99.0, .UnitsInStock = 18, .UnitsOnOrder = 64, .ReorderLevel = 40, .Discontinued = False})
            ProductCollection.Add(New Product With {.ID = 5, .ProductName = "Chef Anton's Gumbo Mix", .QuantityPerUnit = "36 boxes", .UnitPrice = 13.0, .UnitsInStock = 90, .UnitsOnOrder = 10, .ReorderLevel = 50, .Discontinued = False})

            Return ProductCollection
        End Function

    End Class
End Namespace