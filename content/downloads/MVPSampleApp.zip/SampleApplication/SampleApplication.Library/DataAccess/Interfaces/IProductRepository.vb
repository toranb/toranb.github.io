﻿Imports SampleApplication.Library.Entity

Namespace DataAccess.Interfaces
  Public Interface IProductRepository
    Function GetProductCollection() As IEnumerable(Of Product)
  End Interface
End Namespace
