﻿Imports SampleApplication.Library.View.Interfaces
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.Entity.Interfaces
Imports SampleApplication.Library.Service
Imports SampleApplication.Library.Service.Interfaces
Imports SampleApplication.Library.Components.Sorting

Namespace Presenter
    Public Class ProductPresenter

        Private mView As IProductView
        Private mProductService As IProductService

        Public Sub New(ByVal View As IProductView)
            Me.New(View, New ProductService())
        End Sub

        Public Sub New(ByVal View As IProductView, ByVal ProductService As IProductService)
            mView = View
            mProductService = ProductService
        End Sub

        Public Sub OnViewInit()
            PopulateProductCollection()
        End Sub

        Public Sub OnViewLoad()

        End Sub

        Public Sub PopulateProductCollection()
            Dim ProductCollection As New List(Of Product)

            ProductCollection = mProductService.GetProductCollection()

            ProductCollection.Sort(New GenericComparer(Of Product)(mView.SortExpression, mView.SortDirection))

            mView.ProductCollection = ProductCollection
        End Sub

    End Class
End Namespace
