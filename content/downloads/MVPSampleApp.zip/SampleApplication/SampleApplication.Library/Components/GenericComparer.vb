Imports System.Reflection

Namespace Components.Sorting
    ''' <summary>
    ''' Provides a sorting function for generic lists
    ''' </summary>
    Public Class GenericComparer(Of T)
        Implements IComparer(Of T)

        Private mDirection As String
        Private mExpression As String

        Public Sub New(ByVal Expression As String, ByVal Direction As String)
            mExpression = Expression
            mDirection = Direction
        End Sub

        Public Function Compare(ByVal x As T, ByVal y As T) As Integer Implements System.Collections.Generic.IComparer(Of T).Compare
            Dim propertyInfo As PropertyInfo = GetType(T).GetProperty(mExpression)
            Dim obj1 As IComparable = DirectCast(propertyInfo.GetValue(x, Nothing), IComparable)
            Dim obj2 As IComparable = DirectCast(propertyInfo.GetValue(y, Nothing), IComparable)
            If mDirection = "Ascending" Then
                Return obj1.CompareTo(obj2)
            Else
                Return obj2.CompareTo(obj1)
            End If
        End Function
    End Class
End Namespace