﻿Imports SampleApplication.Library.Entity

Namespace View.Interfaces
  Public Interface IProductView
        Property ProductCollection() As List(Of Product)
        ReadOnly Property SortExpression() As String
        ReadOnly Property SortDirection() As String
    End Interface
End Namespace
