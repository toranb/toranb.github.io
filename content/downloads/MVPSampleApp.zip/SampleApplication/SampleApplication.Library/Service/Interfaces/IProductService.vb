﻿Imports SampleApplication.Library.Entity

Namespace Service.Interfaces
  Public Interface IProductService
    Function GetProductCollection() As IEnumerable(Of Product)
  End Interface
End Namespace
