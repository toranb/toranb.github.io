﻿Imports SampleApplication.Library.DataAccess
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.DataAccess.Interfaces
Imports SampleApplication.Library.Service.Interfaces

Namespace Service
  Public Class ProductService
    Implements IProductService

    Private mRepository As IProductRepository

    Public Sub New()
      Me.New(New ProductRepository())
    End Sub

    Public Sub New(ByVal Repository As IProductRepository)
      mRepository = Repository
    End Sub

    Public Function GetProductCollection() As IEnumerable(Of Product) Implements IProductService.GetProductCollection
      Return mRepository.GetProductCollection()
    End Function

  End Class
End Namespace
