﻿/// <reference path="jquery-1.3.1-vsdoc.js" />
//
// Product Specific JS
//
var lastSelectedItem;
var timer;
var browserIsIE = /*@cc_on!@*/false;
// functions
function DeleteProduct(obj, id) {
    $.ajax({
        type: "POST",
        url: "ProductDetailsView.aspx?delete=true&id=" + id,
        data: {},
        dataType: "xml",
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.responseText);
        },
        success: function(xml) {
            for (x = 0; x < xml.getElementsByTagName('data').length; x++) {
                success = xml.getElementsByTagName('valid').item(x).firstChild.data;
            }
            if (success == "true") {
                alert("good job?");
            } else {
                alert("An Exception Occurred During The Disable Of This Product!");
            }
        }
    });
}
function ToggleProductDetails(obj, id) {
    obj.blur();

    if (lastSelectedItem == id) {
        collapseDetails(obj);
    } else {
        if (document.getElementById('detailTR')) {
            collapseDetails(obj);
        }
        GetProductDetails(obj, id);
    }
}
function GetProductDetails(obj, id) {
    $.ajax({
        type: "GET",
        url: "ProductDetailsView.aspx?id=" + id,
        dataType: "html",
        beforeSend: function() { lastSelectedItem = id; },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.responseText);
        },
        success: function(xhtml) {
            var tr = document.createElement('tr');
            tr.id = "detailTR";

            var td = document.createElement('td');
            td.colSpan = 3;

            var container = document.createElement('div');
            container.id = "fillDiv";

            obj.parentNode.parentNode.parentNode.insertBefore(tr, obj.parentNode.parentNode.nextSibling);

            container.innerHTML = xhtml;

            td.appendChild(container);
            tr.appendChild(td);

            //cleanup the html from asp.net quick
            removeExtraFormData($("#fillDiv"));
        }
    });
}
function UpdateProductDetails(obj) {
    obj.blur();

    //clear the status before we do anything else
    removeStatusIndicator();

    var ProductName = $("#txtProductName").val();
    var QuantityPerUnit = $("#txtQuantityPerUnit").val();
    var UnitPrice = $("#txtUnitPrice").val();
    var UnitsInStock = $("#txtUnitsInStock").val();
    var UnitsOnOrder = $("#txtUnitsOnOrder").val();
    var ReorderLevel = $("#txtReorderLevel").val();
    var Discontinued = $("#txtDiscontinued").val();
    var Supplier = $("#ddlSupplier").attr('selectedIndex');
    var Category = $("#ddlCategory").attr('selectedIndex');

    var info = { ProductName: ProductName, QuantityPerUnit: QuantityPerUnit, UnitPrice: UnitPrice, UnitsInStock: UnitsInStock, UnitsOnOrder: UnitsOnOrder, ReorderLevel: ReorderLevel, Discontinued: Discontinued, Supplier: Supplier, Category: Category };

    $.ajax({
        type: "POST",
        url: obj.href + "&update=true",
        data: info,
        dataType: "xml",
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(XMLHttpRequest.responseText);
        },
        success: function(xml) {
            var statusTimeout;
            for (x = 0; x < xml.getElementsByTagName('data').length; x++) {
                success = xml.getElementsByTagName('valid').item(x).firstChild.data;
            }
            if (success == "true") {
                //dynamically change the client side to reflect the changes by the Product
                //first get the values as they exist in the inputs
                var UpdatedProductName = document.getElementById('txtProductName').value;

                var previousTableCell;
                if (browserIsIE) {
                    previousTableCell = document.getElementById('detailTR').previousSibling.childNodes[0].firstChild.id;
                } else {
                    previousTableCell = document.getElementById('detailTR').previousSibling.firstChild.nextSibling.childNodes[1].id;
                }
                //next get the base element name because .net puts a long prefix on each control name
                var base = previousTableCell.slice(0, previousTableCell.length - 14);

                //now add the base to each element and innerHTML with the changes we captured above
                document.getElementById(base + 'lnkProductName').innerHTML = UpdatedProductName;

                //Inform the Product that the data was saved without error
                statusTimeout = 5000;

                var lblStatus = document.getElementById('lblUpdateStatus');

                //clear the text information currently in status
                lblStatus.innerHTML = "";

                lblStatus.style.color = "green";

                exceptions_text = document.createTextNode('Saved');
                lblStatus.appendChild(exceptions_text);
            } else {
                statusTimeout = 10000;
                SetProductFeedbackWithBrokenRules(xml);
            }

            clearTimeout(timer);
            timer = window.setTimeout(function() { removeStatusIndicator(); }, statusTimeout);
        }
    });
}
function removeExtraFormData(parentObj) {
    //some asp.net cleanup from the ajax request
    //this is only needed when the server side html
    //coming back has a form + viewstate + event args attached
    //typically you only see this when we ajax a gridview or dropdownlist

    //This function will remove any div inside the second form w/out an id
    //Currently when asp.net adds the viewstate + event args they don't have an id - thus remove them
    $('form:eq(1)').children().each(
        function() {
            if ($('form:eq(1)').find('div').filter(function() { return $(this).attr('id') == ''; }).remove());
        }
    );

    //Capture the remaining children
    var children = $('form:eq(1)').children();

    // Remove the form
    $('form:eq(1)').remove();

    // append the correct child element back to the DOM
    parentObj.append(children);
}
function collapseDetails(obj) {
    newInt = 0 //used in the default.aspx page to reset the int number used to keep track of chk box count
    if (document.getElementById('detailTR')) {
        obj.parentNode.parentNode.parentNode.removeChild(document.getElementById('detailTR'));
        lastSelectedItem = null;
    }
}
function removeStatusIndicator() {
    if (document.getElementById('lblUpdateStatus')) {
        document.getElementById('lblUpdateStatus').innerHTML = "";
    }
}