﻿Imports SampleApplication.Library.View.Interfaces
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.Presenter
Imports System.Security.Cryptography.X509Certificates
Imports System.Net.Security
Imports SampleApplication.Library.Components.LookupList.Interfaces
Imports SampleApplication.Library.Components.LookupList.Web

Partial Public Class ProductDetailsView
    Inherits System.Web.UI.Page
    Implements IProductView

    Private mPresenter As ProductPresenter
    Private mReturnXML As String = "<data><valid>false</valid></data>"

    Protected Overrides Sub OnInit(ByVal e As System.EventArgs)
        MyBase.OnInit(e)
        mPresenter = New ProductPresenter(Me)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Cache.SetCacheability(HttpCacheability.NoCache)

        If Request.HttpMethod = "GET" Then
            If ID1 > 0 Then
                mPresenter.GetProductById(ID1)
            End If

            lnkUpdate.HRef = "ProductDetailsView.aspx?id=" + ID1.ToString()
        ElseIf Request.HttpMethod = "POST" Then
            '**
            '** This hack was done because for some odd reason the PUT/DELETE verbs are not enabled in IIS6 by default
            '**
            Dim cmdDelete As Boolean
            If Request.QueryString("delete") = "" Then
                cmdDelete = False
            Else
                cmdDelete = True
            End If

            Dim cmdUpdate As Boolean
            If Request.QueryString("update") = "" Then
                cmdUpdate = False
            Else
                cmdUpdate = True
            End If

            If cmdDelete Then
                mPresenter.DeleteProductById()
            ElseIf cmdUpdate Then
                mPresenter.UpdateProduct()
            End If
            Response.ContentType = "text/xml"
            Response.Write(Me.ReturnXML)
            Response.End()
        Else
            Response.StatusCode = 404
            Response.End()
        End If
    End Sub

#Region "IProductView Properties"
    Public Property ID1() As Integer Implements SampleApplication.Library.View.Interfaces.IProductView.ID
        Get
            Dim ajax = Request.QueryString("id")
            If Not ajax = "" Then
                Return ajax
            End If

            Return 0
        End Get
        Set(ByVal value As Integer)

        End Set
    End Property

    Public Property ProductName() As String Implements SampleApplication.Library.View.Interfaces.IProductView.ProductName
        Get
            Dim ajax = Request.Form("ProductName")
            If Not ajax = "" Then
                Return ajax
            End If

            Return txtProductName.Value
        End Get
        Set(ByVal value As String)
            txtProductName.Value = value
        End Set
    End Property

    Public Property QuantityPerUnit() As String Implements SampleApplication.Library.View.Interfaces.IProductView.QuantityPerUnit
        Get
            Dim ajax = Request.Form("QuantityPerUnit")
            If Not ajax = "" Then
                Return ajax
            End If

            Return txtQuantityPerUnit.Value
        End Get
        Set(ByVal value As String)
            txtQuantityPerUnit.Value = value
        End Set
    End Property

    Public Property UnitPrice() As Nullable(Of Decimal) Implements SampleApplication.Library.View.Interfaces.IProductView.UnitPrice
        Get
            Dim ajax = Request.Form("UnitPrice")
            If Not ajax = "" Then
                Return ajax
            End If

            Return txtUnitPrice.Value
        End Get
        Set(ByVal value As Nullable(Of Decimal))
            txtUnitPrice.Value = value
        End Set
    End Property

    Public Property UnitsInStock() As Nullable(Of Integer) Implements SampleApplication.Library.View.Interfaces.IProductView.UnitsInStock
        Get
            Dim ajax = Request.Form("UnitsInStock")
            If Not ajax = "" Then
                Return ajax
            End If

            Return txtUnitsInStock.Value
        End Get
        Set(ByVal value As Nullable(Of Integer))
            txtUnitsInStock.Value = value
        End Set
    End Property

    Public Property UnitsOnOrder() As Nullable(Of Integer) Implements SampleApplication.Library.View.Interfaces.IProductView.UnitsOnOrder
        Get
            Dim ajax = Request.Form("UnitsOnOrder")
            If Not ajax = "" Then
                Return ajax
            End If

            Return txtUnitsOnOrder.Value
        End Get
        Set(ByVal value As Nullable(Of Integer))
            txtUnitsOnOrder.Value = value
        End Set
    End Property

    Public Property ReorderLevel() As Nullable(Of Integer) Implements SampleApplication.Library.View.Interfaces.IProductView.ReorderLevel
        Get
            Dim ajax = Request.Form("ReorderLevel")
            If Not ajax = "" Then
                Return ajax
            End If

            Return txtReorderLevel.Value
        End Get
        Set(ByVal value As Nullable(Of Integer))
            txtReorderLevel.Value = value
        End Set
    End Property

    Public Property Discontinued() As Boolean Implements SampleApplication.Library.View.Interfaces.IProductView.Discontinued
        Get
            Dim ajax = Request.Form("Discontinued")
            If Not ajax = "" Then
                Return ajax
            End If

            Return txtDiscontinued.Value
        End Get
        Set(ByVal value As Boolean)
            txtDiscontinued.Value = value
        End Set
    End Property

    Public Property ProductCollection() As System.Collections.Generic.List(Of Library.Entity.Product) Implements Library.View.Interfaces.IProductView.ProductCollection
        Get

        End Get
        Set(ByVal value As System.Collections.Generic.List(Of Library.Entity.Product))

        End Set
    End Property

    Public ReadOnly Property SortDirection() As String Implements Library.View.Interfaces.IProductView.SortDirection
        Get

        End Get
    End Property

    Public ReadOnly Property SortExpression() As String Implements Library.View.Interfaces.IProductView.SortExpression
        Get

        End Get
    End Property

    Public Property ReturnXML() As String Implements Library.View.Interfaces.IProductView.ReturnXML
        Get
            Return mReturnXML
        End Get
        Set(ByVal value As String)
            mReturnXML = value
        End Set
    End Property

    Public ReadOnly Property CategoryCollection() As ILookupList Implements Library.View.Interfaces.IProductView.CategoryCollection
        Get
            Return New WebLookupList(ddlCategory)
        End Get
    End Property

    Public ReadOnly Property SupplierCollection() As ILookupList Implements Library.View.Interfaces.IProductView.SupplierCollection
        Get
            Return New WebLookupList(ddlSupplier)
        End Get
    End Property

    Public ReadOnly Property SelectedCategory() As Integer Implements Library.View.Interfaces.IProductView.SelectedCategory
        Get
            Dim ajax = Request.Form("Category")
            If Not ajax = "" Then
                Return ajax
            End If

            Return 0
        End Get
    End Property

    Public ReadOnly Property SelectedSupplier() As Integer Implements Library.View.Interfaces.IProductView.SelectedSupplier
        Get
            Dim ajax = Request.Form("Supplier")
            If Not ajax = "" Then
                Return ajax
            End If

            Return 0
        End Get
    End Property
#End Region

End Class

