﻿Imports SampleApplication.Library.View.Interfaces
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.Presenter

Partial Public Class _Default
    Inherits System.Web.UI.Page
    Implements IProductView

    Private mPresenter As ProductPresenter

    Protected Overrides Sub OnInit(ByVal e As System.EventArgs)
        MyBase.OnInit(e)

        mPresenter = New ProductPresenter(Me)
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If IsPostBack Then
            mPresenter.OnViewLoad()
        Else
            mPresenter.OnViewInit()
        End If
    End Sub

#Region "Gridview RowDataBound"
    Protected Sub gridSuppliers_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gridProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.Header Then
            e.Row.Cells((IIf(ViewState("PreviousHeaderIndex") Is Nothing, 0, CInt(ViewState("PreviousHeaderIndex"))))).CssClass += (IIf(DirectCast(ViewState("PreviousSortDirection"), String) = "Ascending", " sortasc", " sortdesc"))
            Return
        ElseIf e.Row.RowType <> DataControlRowType.DataRow Then
            Return
        End If

        Dim ProductObject As Product = DirectCast(e.Row.DataItem, Product)

        Dim lnkProductName As HtmlAnchor = DirectCast(e.Row.FindControl("lnkProductName"), HtmlAnchor)
        Dim lblQuantityPerUnit As HtmlContainerControl = DirectCast(e.Row.FindControl("lblQuantityPerUnit"), HtmlContainerControl)
        Dim lblUnitsInStock As HtmlContainerControl = DirectCast(e.Row.FindControl("lblUnitsInStock"), HtmlContainerControl)

        lnkProductName.InnerHtml = ProductObject.ProductName
        lnkProductName.HRef = "ProductDetailsView.aspx?id=" + ProductObject.ID.ToString()
        lnkProductName.Attributes.Add("onclick", "ToggleProductDetails(this, " + ProductObject.ID.ToString() + "); return false;")
        lblQuantityPerUnit.InnerHtml = ProductObject.QuantityPerUnit.ToString()
        lblUnitsInStock.InnerHtml = ProductObject.UnitsInStock.ToString()
    End Sub
#End Region

#Region "Gridview PageIndexChanging"
    Protected Sub gridProducts_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles gridProducts.PageIndexChanging
        gridProducts.PageIndex = e.NewPageIndex
        mPresenter.PopulateProductCollection()
    End Sub
#End Region

#Region "Gridview Sorting"
    Private Sub gridSuppliers_Sorting(ByVal sender As Object, ByVal e As GridViewSortEventArgs) Handles gridProducts.Sorting
        If DirectCast(ViewState("PreviousSortExpression"), String) = e.SortExpression Then
            If DirectCast(ViewState("PreviousSortDirection"), String) = "Ascending" Then
                e.SortDirection = System.Web.UI.WebControls.SortDirection.Descending
                ViewState("PreviousSortDirection") = "Descending"
            Else
                e.SortDirection = System.Web.UI.WebControls.SortDirection.Ascending
                ViewState("PreviousSortDirection") = "Ascending"
            End If
        Else
            e.SortDirection = System.Web.UI.WebControls.SortDirection.Ascending
            ViewState("PreviousSortDirection") = "Ascending"
        End If
        ViewState("PreviousSortExpression") = e.SortExpression

        Dim gv As GridView = DirectCast(sender, GridView)
        If e.SortExpression.Length > 0 Then
            For Each field As DataControlField In gv.Columns
                If field.SortExpression = e.SortExpression Then
                    ViewState("PreviousHeaderIndex") = gv.Columns.IndexOf(field)
                    Exit For
                End If
            Next
        End If
        mPresenter.PopulateProductCollection()
    End Sub
#End Region

#Region "IProductView Properties"

    Public Property ProductCollection() As System.Collections.Generic.List(Of Library.Entity.Product) Implements Library.View.Interfaces.IProductView.ProductCollection
        Get
            Return DirectCast(gridProducts.DataSource(), List(Of Product))
        End Get
        Set(ByVal value As System.Collections.Generic.List(Of Library.Entity.Product))
            gridProducts.DataSource = value
            gridProducts.DataBind()
        End Set
    End Property

    Public ReadOnly Property SortDirection() As String Implements Library.View.Interfaces.IProductView.SortDirection
        Get
            If ViewState("PreviousSortDirection") Is Nothing Then
                ViewState("PreviousSortDirection") = "Ascending"
            End If
            Return DirectCast(ViewState("PreviousSortDirection"), String)
        End Get
    End Property

    Public ReadOnly Property SortExpression() As String Implements Library.View.Interfaces.IProductView.SortExpression
        Get
            If ViewState("PreviousSortExpression") Is Nothing Then
                ViewState("PreviousSortExpression") = "ProductName"
            End If
            Return DirectCast(ViewState("PreviousSortExpression"), String)
        End Get
    End Property
#End Region

    Public ReadOnly Property CategoryCollection() As Library.Components.LookupList.Interfaces.ILookupList Implements Library.View.Interfaces.IProductView.CategoryCollection
        Get

        End Get
    End Property

    Public Property Discontinued() As Boolean Implements Library.View.Interfaces.IProductView.Discontinued
        Get

        End Get
        Set(ByVal value As Boolean)

        End Set
    End Property

    Public Property ID1() As Integer Implements Library.View.Interfaces.IProductView.ID
        Get

        End Get
        Set(ByVal value As Integer)

        End Set
    End Property

    Public Property ProductName() As String Implements Library.View.Interfaces.IProductView.ProductName
        Get

        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public Property QuantityPerUnit() As String Implements Library.View.Interfaces.IProductView.QuantityPerUnit
        Get

        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public Property ReorderLevel() As Integer? Implements Library.View.Interfaces.IProductView.ReorderLevel
        Get

        End Get
        Set(ByVal value As Integer?)

        End Set
    End Property

    Public Property ReturnXML() As String Implements Library.View.Interfaces.IProductView.ReturnXML
        Get

        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public ReadOnly Property SupplierCollection() As Library.Components.LookupList.Interfaces.ILookupList Implements Library.View.Interfaces.IProductView.SupplierCollection
        Get

        End Get
    End Property

    Public Property UnitPrice() As Decimal? Implements Library.View.Interfaces.IProductView.UnitPrice
        Get

        End Get
        Set(ByVal value As Decimal?)

        End Set
    End Property

    Public Property UnitsInStock() As Integer? Implements Library.View.Interfaces.IProductView.UnitsInStock
        Get

        End Get
        Set(ByVal value As Integer?)

        End Set
    End Property

    Public Property UnitsOnOrder() As Integer? Implements Library.View.Interfaces.IProductView.UnitsOnOrder
        Get

        End Get
        Set(ByVal value As Integer?)

        End Set
    End Property

    Public ReadOnly Property SelectedCategory() As Integer Implements Library.View.Interfaces.IProductView.SelectedCategory
        Get
 
        End Get
    End Property

    Public ReadOnly Property SelectedSupplier() As Integer Implements Library.View.Interfaces.IProductView.SelectedSupplier
        Get

        End Get
    End Property
End Class