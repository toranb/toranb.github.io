﻿Imports SampleApplication.Library.View.Interfaces
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.Entity.Interfaces
Imports SampleApplication.Library.Service
Imports SampleApplication.Library.Service.Interfaces
Imports SampleApplication.Library.Components.Entities
Imports SampleApplication.Library.Components.Sorting
Imports SampleApplication.Library.Components.LookupList.Interfaces
Imports SampleApplication.Library.Components.LookupList

Namespace Presenter
    Public Class ProductPresenter

        Private mView As IProductView
        Private mProductService As IProductService
        Private mSupplierService As ISupplierService
        Private mCategoryService As ICategoryService

        Public Sub New(ByVal View As IProductView)
            Me.New(View, New ProductService(), New SupplierService(), New CategoryService())
        End Sub

        Public Sub New(ByVal View As IProductView, ByVal ProductService As IProductService, ByVal SupplierService As ISupplierService, ByVal CategoryService As ICategoryService)
            mView = View
            mProductService = ProductService
            mSupplierService = SupplierService
            mCategoryService = CategoryService
        End Sub

        Public Sub OnViewInit()
            PopulateProductCollection()
        End Sub

        Public Sub OnViewLoad()

        End Sub

        Public Sub PopulateProductCollection()
            Dim ProductCollection As New List(Of Product)

            ProductCollection = mProductService.GetProductCollection()

            ProductCollection.Sort(New GenericComparer(Of Product)(mView.SortExpression, mView.SortDirection))

            mView.ProductCollection = ProductCollection
        End Sub

        Public Sub UpdateProduct()
            Dim ProductObject As New Product()

            If mView.ID > 0 Then
                ProductObject.ID = mView.ID
                ProductObject.ProductName = mView.ProductName
                ProductObject.QuantityPerUnit = mView.QuantityPerUnit
                ProductObject.UnitPrice = mView.UnitPrice
                ProductObject.UnitsInStock = mView.UnitsInStock
                ProductObject.UnitsOnOrder = mView.UnitsOnOrder
                ProductObject.ReorderLevel = mView.ReorderLevel
                ProductObject.Discontinued = mView.Discontinued
                ProductObject.Supplier.ID = mView.SelectedSupplier
                ProductObject.Category.ID = mView.SelectedCategory

                mProductService.SaveProduct(ProductObject)

                mView.ReturnXML = "<data><valid>true</valid></data>"
            End If

        End Sub

        Public Sub GetProductById(ByVal id As Integer)
            Dim ProductObject As Product = mProductService.GetProductById(id)

            If ProductObject IsNot Nothing Then
                mView.ID = ProductObject.ID
                mView.ProductName = ProductObject.ProductName
                mView.QuantityPerUnit = ProductObject.QuantityPerUnit
                mView.UnitPrice = ProductObject.UnitPrice
                mView.UnitsInStock = ProductObject.UnitsInStock
                mView.UnitsOnOrder = ProductObject.UnitsOnOrder
                mView.ReorderLevel = ProductObject.ReorderLevel
                mView.Discontinued = ProductObject.Discontinued
            End If

            PopulateCategoryDDL(ProductObject)
            PopulateSupplierDDL(ProductObject)
        End Sub

        Public Sub DeleteProductById()
            mProductService.DeleteProductByID(mView.ID)

            mView.ReturnXML = "<data><valid>true</valid></data>"
        End Sub

        Public Sub PopulateSupplierDDL(Optional ByVal ProductObject As Product = Nothing)
            Dim SupplierCollection As List(Of Supplier) = mSupplierService.GetSupplierCollection()

            Dim SupplierLookupDTO As New List(Of ILookupDTO)

            SupplierLookupDTO.Add(New LookupDTO(" ", 0)) 'insert a blank row ;)

            For Each Supplier In SupplierCollection
                SupplierLookupDTO.Add(New LookupDTO(Supplier.CompanyName, Supplier.ID.ToString()))
            Next

            Dim LookupCollectionObject As New LookupCollection(SupplierLookupDTO)
            LookupCollectionObject.BindTo(mView.SupplierCollection)

            If ProductObject Is Nothing Then
                Return
            End If

            If SupplierCollection Is Nothing Then
                Return
            End If

            For i = 0 To SupplierCollection.Count - 1
                If SupplierCollection(i).ID = ProductObject.Supplier.ID Then
                    LookupCollectionObject.SelectedIndex = (i + 1) 'because we start at 0 instead of 1 (we inserted the blank row above)
                    Exit For
                End If
            Next
        End Sub

        Public Sub PopulateCategoryDDL(Optional ByVal ProductObject As Product = Nothing)
            Dim CategoryCollection As List(Of Category) = mCategoryService.GetCategoryCollection()

            Dim CategoryLookupDTO As New List(Of ILookupDTO)

            CategoryLookupDTO.Add(New LookupDTO(" ", 0)) 'insert a blank row ;)

            For Each Category In CategoryCollection
                CategoryLookupDTO.Add(New LookupDTO(Category.Description, Category.ID.ToString()))
            Next

            Dim LookupCollectionObject As New LookupCollection(CategoryLookupDTO)
            LookupCollectionObject.BindTo(mView.CategoryCollection)

            If ProductObject Is Nothing Then
                Return
            End If

            If CategoryCollection Is Nothing Then
                Return
            End If

            For i = 0 To CategoryCollection.Count - 1
                If CategoryCollection(i).ID = ProductObject.Category.ID Then
                    LookupCollectionObject.SelectedIndex = (i + 1) 'because we start at 0 instead of 1 (we inserted the blank row above)
                    Exit For
                End If
            Next
        End Sub

    End Class
End Namespace
