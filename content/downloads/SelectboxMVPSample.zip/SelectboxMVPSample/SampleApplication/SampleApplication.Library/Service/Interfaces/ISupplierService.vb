﻿Imports SampleApplication.Library.Entity

Namespace Service.Interfaces
  Public Interface ISupplierService
    Function GetSupplierCollection() As IEnumerable(Of Supplier)
    Function GetSupplierById(ByVal id As Integer) As Supplier
    Sub SaveSupplier(ByVal SupplierObject As Supplier)
    Sub DeleteSupplierByID(ByVal id As Integer)
    Function GetSupplierByProductID(ByVal id As Integer) As Supplier
  End Interface
End Namespace
