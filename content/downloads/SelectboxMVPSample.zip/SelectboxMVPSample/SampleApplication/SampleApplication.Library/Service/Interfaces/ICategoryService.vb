﻿Imports SampleApplication.Library.Entity

Namespace Service.Interfaces
  Public Interface ICategoryService
    Function GetCategoryCollection() As IEnumerable(Of Category)
    Function GetCategoryById(ByVal id As Integer) As Category
    Sub SaveCategory(ByVal CategoryObject As Category)
    Sub DeleteCategoryByID(ByVal id As Integer)
    Function GetCategoryByProductID(ByVal id As Integer) As Category
  End Interface
End Namespace
