﻿Imports SampleApplication.Library.DataAccess
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.DataAccess.Interfaces
Imports SampleApplication.Library.Service.Interfaces

Namespace Service
  Public Class SupplierService
    Implements ISupplierService

    Private mRepository As ISupplierRepository

    Public Sub New()
      Me.New(New SupplierRepository())
    End Sub

    Public Sub New(ByVal Repository As ISupplierRepository)
      mRepository = Repository
    End Sub

    Public Sub DeleteSupplierByID(ByVal id As Integer) Implements ISupplierService.DeleteSupplierByID
      mRepository.DeleteSupplierByID(id)
    End Sub

    Public Function GetSupplierById(ByVal id As Integer) As Supplier Implements ISupplierService.GetSupplierById
      Return mRepository.GetSupplierById(id)
    End Function

    Public Function GetSupplierCollection() As IEnumerable(Of Supplier) Implements ISupplierService.GetSupplierCollection
      Return mRepository.GetSupplierCollection()
    End Function

    Public Sub SaveSupplier(ByVal SupplierObject As Supplier) Implements ISupplierService.SaveSupplier
      mRepository.SaveSupplier(SupplierObject)
    End Sub

    Public Function GetSupplierByProductID(ByVal id As Integer) As Supplier Implements ISupplierService.GetSupplierByProductID
      Return mRepository.GetSupplierByProductID(id)
    End Function

  End Class
End Namespace
