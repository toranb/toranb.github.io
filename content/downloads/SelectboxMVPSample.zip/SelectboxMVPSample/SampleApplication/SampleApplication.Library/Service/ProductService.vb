﻿Imports SampleApplication.Library.DataAccess
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.DataAccess.Interfaces
Imports SampleApplication.Library.Service.Interfaces

Namespace Service
    Public Class ProductService
        Implements IProductService

        Private mRepository As IProductRepository

        Public Sub New()
            Me.New(New ProductRepository())
        End Sub

        Public Sub New(ByVal Repository As IProductRepository)
            mRepository = Repository
        End Sub

        Public Sub DeleteProductByID(ByVal id As Integer) Implements IProductService.DeleteProductByID
            mRepository.DeleteProductByID(id)
        End Sub

        Public Function GetProductById(ByVal id As Integer) As Product Implements IProductService.GetProductById
            Return mRepository.GetProductById(id)
        End Function

        Public Function GetProductCollection() As IEnumerable(Of Product) Implements IProductService.GetProductCollection
            Return mRepository.GetProductCollection()
        End Function

        Public Sub SaveProduct(ByVal ProductObject As Product) Implements IProductService.SaveProduct
            mRepository.SaveProduct(ProductObject)
        End Sub

    End Class
End Namespace
