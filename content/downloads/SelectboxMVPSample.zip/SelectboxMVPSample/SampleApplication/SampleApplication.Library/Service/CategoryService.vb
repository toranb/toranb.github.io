﻿Imports SampleApplication.Library.DataAccess
Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.DataAccess.Interfaces
Imports SampleApplication.Library.Service.Interfaces

Namespace Service
  Public Class CategoryService
    Implements ICategoryService

    Private mRepository As ICategoryRepository

    Public Sub New()
      Me.New(New CategoryRepository())
    End Sub

    Public Sub New(ByVal Repository As ICategoryRepository)
      mRepository = Repository
    End Sub

    Public Sub DeleteCategoryByID(ByVal id As Integer) Implements ICategoryService.DeleteCategoryByID
      mRepository.DeleteCategoryByID(id)
    End Sub

    Public Function GetCategoryById(ByVal id As Integer) As Category Implements ICategoryService.GetCategoryById
      Return mRepository.GetCategoryById(id)
    End Function

    Public Function GetCategoryCollection() As IEnumerable(Of Category) Implements ICategoryService.GetCategoryCollection
      Return mRepository.GetCategoryCollection()
    End Function

    Public Sub SaveCategory(ByVal CategoryObject As Category) Implements ICategoryService.SaveCategory
      mRepository.SaveCategory(CategoryObject)
    End Sub

    Public Function GetCategoryByProductID(ByVal id As Integer) As Category Implements ICategoryService.GetCategoryByProductID
      Return mRepository.GetCategoryByProductID(id)
    End Function

  End Class
End Namespace
