﻿Imports SampleApplication.Library.Service
Imports SampleApplication.Library.Service.Interfaces
Imports SampleApplication.Library.Entity.Interfaces

Namespace Entity
    Public Class Product
        Implements IProduct

        ' This service is used to lazy load Supplier data
        Private mSupplierService As ISupplierService
        ' This service is used to lazy load Category data
        Private mCategoryService As ICategoryService

        Public Sub New()
            Me.New(New SupplierService(), New CategoryService())
        End Sub

        Public Sub New(ByVal SupplierService As ISupplierService, ByVal CategoryService As ICategoryService)
            mSupplierService = SupplierService
            mCategoryService = CategoryService
        End Sub

        Public Sub New(ByVal ID As Integer, ByVal ProductName As String, ByVal QuantityPerUnit As String, ByVal UnitPrice As Nullable(Of Decimal), ByVal UnitsInStock As Nullable(Of Integer), ByVal UnitsOnOrder As Nullable(Of Integer), ByVal ReorderLevel As Nullable(Of Integer), ByVal Discontinued As Boolean)
            mID = ID
            mProductName = ProductName
            mQuantityPerUnit = QuantityPerUnit
            mUnitPrice = UnitPrice
            mUnitsInStock = UnitsInStock
            mUnitsOnOrder = UnitsOnOrder
            mReorderLevel = ReorderLevel
            mDiscontinued = Discontinued
            mSupplierService = New SupplierService()
            mCategoryService = New CategoryService()
        End Sub

        Private mID As Integer
        Public Property ID() As Integer Implements IProduct.ID
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mProductName As String
        Public Property ProductName() As String Implements IProduct.ProductName
            Get
                Return mProductName
            End Get
            Set(ByVal value As String)
                mProductName = value
            End Set
        End Property

        Private mQuantityPerUnit As String
        Public Property QuantityPerUnit() As String Implements IProduct.QuantityPerUnit
            Get
                Return mQuantityPerUnit
            End Get
            Set(ByVal value As String)
                mQuantityPerUnit = value
            End Set
        End Property

        Private mUnitPrice As Nullable(Of Decimal)
        Public Property UnitPrice() As Nullable(Of Decimal) Implements IProduct.UnitPrice
            Get
                Return mUnitPrice
            End Get
            Set(ByVal value As Nullable(Of Decimal))
                mUnitPrice = value
            End Set
        End Property

        Private mUnitsInStock As Nullable(Of Integer)
        Public Property UnitsInStock() As Nullable(Of Integer) Implements IProduct.UnitsInStock
            Get
                Return mUnitsInStock
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mUnitsInStock = value
            End Set
        End Property

        Private mUnitsOnOrder As Nullable(Of Integer)
        Public Property UnitsOnOrder() As Nullable(Of Integer) Implements IProduct.UnitsOnOrder
            Get
                Return mUnitsOnOrder
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mUnitsOnOrder = value
            End Set
        End Property

        Private mReorderLevel As Nullable(Of Integer)
        Public Property ReorderLevel() As Nullable(Of Integer) Implements IProduct.ReorderLevel
            Get
                Return mReorderLevel
            End Get
            Set(ByVal value As Nullable(Of Integer))
                mReorderLevel = value
            End Set
        End Property

        Private mDiscontinued As Boolean
        Public Property Discontinued() As Boolean Implements IProduct.Discontinued
            Get
                Return mDiscontinued
            End Get
            Set(ByVal value As Boolean)
                mDiscontinued = value
            End Set
        End Property

        Private mSupplier As Supplier
        Public ReadOnly Property Supplier() As Supplier Implements IProduct.Supplier
            Get
                If mSupplier Is Nothing Then
                    ' lazy load the Supplier object
                    mSupplier = mSupplierService.GetSupplierByProductID(mID)
                    If mSupplier Is Nothing Then
                        ' this is done to avoid a null ref exception
                        mSupplier = New Supplier()
                    End If
                End If
                Return mSupplier
            End Get
        End Property
        Private mCategory As Category
        Public ReadOnly Property Category() As Category Implements IProduct.Category
            Get
                If mCategory Is Nothing Then
                    ' lazy load the Category object
                    mCategory = mCategoryService.GetCategoryByProductID(mID)
                    If mCategory Is Nothing Then
                        ' this is done to avoid a null ref exception
                        mCategory = New Category()
                    End If
                End If
                Return mCategory
            End Get
        End Property
    End Class
End Namespace
