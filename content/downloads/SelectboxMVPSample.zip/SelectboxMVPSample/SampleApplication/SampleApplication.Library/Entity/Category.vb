﻿Imports SampleApplication.Library.Service
Imports SampleApplication.Library.Service.Interfaces
Imports SampleApplication.Library.Entity.Interfaces

Namespace Entity
  Public Class Category
        Implements ICategory

        Public Sub New()

        End Sub

        Public Sub New(ByVal ID As Integer, ByVal CategoryName As String, ByVal Description As String)
            mID = ID
            mCategoryName = CategoryName
            mDescription = Description
        End Sub

        Private mID As Integer
        Public Property ID() As Integer Implements ICategory.ID
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mCategoryName As String
        Public Property CategoryName() As String Implements ICategory.CategoryName
            Get
                Return mCategoryName
            End Get
            Set(ByVal value As String)
                mCategoryName = value
            End Set
        End Property

        Private mDescription As String
        Public Property Description() As String Implements ICategory.Description
            Get
                Return mDescription
            End Get
            Set(ByVal value As String)
                mDescription = value
            End Set
        End Property

    End Class
End Namespace
