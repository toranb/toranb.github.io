﻿Imports SampleApplication.Library.Service
Imports SampleApplication.Library.Service.Interfaces
Imports SampleApplication.Library.Entity.Interfaces

Namespace Entity
  Public Class Supplier
        Implements ISupplier

        Public Sub New()

        End Sub

        Public Sub New(ByVal ID As Integer, ByVal CompanyName As String, ByVal ContactName As String, ByVal ContactTitle As String, ByVal Address As String, ByVal City As String, ByVal Region As String, ByVal PostalCode As String, ByVal Country As String, ByVal Phone As String, ByVal Fax As String, ByVal HomePage As String)
            mID = ID
            mCompanyName = CompanyName
            mContactName = ContactName
            mContactTitle = ContactTitle
            mAddress = Address
            mCity = City
            mRegion = Region
            mPostalCode = PostalCode
            mCountry = Country
            mPhone = Phone
            mFax = Fax
            mHomePage = HomePage
        End Sub

        Private mID As Integer
        Public Property ID() As Integer Implements ISupplier.ID
            Get
                Return mID
            End Get
            Set(ByVal value As Integer)
                mID = value
            End Set
        End Property

        Private mCompanyName As String
        Public Property CompanyName() As String Implements ISupplier.CompanyName
            Get
                Return mCompanyName
            End Get
            Set(ByVal value As String)
                mCompanyName = value
            End Set
        End Property

        Private mContactName As String
        Public Property ContactName() As String Implements ISupplier.ContactName
            Get
                Return mContactName
            End Get
            Set(ByVal value As String)
                mContactName = value
            End Set
        End Property

        Private mContactTitle As String
        Public Property ContactTitle() As String Implements ISupplier.ContactTitle
            Get
                Return mContactTitle
            End Get
            Set(ByVal value As String)
                mContactTitle = value
            End Set
        End Property

        Private mAddress As String
        Public Property Address() As String Implements ISupplier.Address
            Get
                Return mAddress
            End Get
            Set(ByVal value As String)
                mAddress = value
            End Set
        End Property

        Private mCity As String
        Public Property City() As String Implements ISupplier.City
            Get
                Return mCity
            End Get
            Set(ByVal value As String)
                mCity = value
            End Set
        End Property

        Private mRegion As String
        Public Property Region() As String Implements ISupplier.Region
            Get
                Return mRegion
            End Get
            Set(ByVal value As String)
                mRegion = value
            End Set
        End Property

        Private mPostalCode As String
        Public Property PostalCode() As String Implements ISupplier.PostalCode
            Get
                Return mPostalCode
            End Get
            Set(ByVal value As String)
                mPostalCode = value
            End Set
        End Property

        Private mCountry As String
        Public Property Country() As String Implements ISupplier.Country
            Get
                Return mCountry
            End Get
            Set(ByVal value As String)
                mCountry = value
            End Set
        End Property

        Private mPhone As String
        Public Property Phone() As String Implements ISupplier.Phone
            Get
                Return mPhone
            End Get
            Set(ByVal value As String)
                mPhone = value
            End Set
        End Property

        Private mFax As String
        Public Property Fax() As String Implements ISupplier.Fax
            Get
                Return mFax
            End Get
            Set(ByVal value As String)
                mFax = value
            End Set
        End Property

        Private mHomePage As String
        Public Property HomePage() As String Implements ISupplier.HomePage
            Get
                Return mHomePage
            End Get
            Set(ByVal value As String)
                mHomePage = value
            End Set
        End Property

    End Class
End Namespace
