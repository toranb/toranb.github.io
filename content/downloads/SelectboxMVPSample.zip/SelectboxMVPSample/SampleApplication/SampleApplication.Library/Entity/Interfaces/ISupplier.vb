﻿Imports SampleApplication.Library.Entity

Namespace Entity.Interfaces
  Interface ISupplier
    Property ID() As Integer
    Property CompanyName() As String
    Property ContactName() As String
    Property ContactTitle() As String
    Property Address() As String
    Property City() As String
    Property Region() As String
    Property PostalCode() As String
    Property Country() As String
    Property Phone() As String
    Property Fax() As String
    Property HomePage() As String
  End Interface
End Namespace
