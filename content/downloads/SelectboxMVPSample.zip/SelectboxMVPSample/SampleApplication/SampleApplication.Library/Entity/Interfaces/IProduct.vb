﻿Imports SampleApplication.Library.Entity

Namespace Entity.Interfaces
    Interface IProduct
        Property ID() As Integer
        Property ProductName() As String
        Property QuantityPerUnit() As String
        Property UnitPrice() As Nullable(Of Decimal)
        Property UnitsInStock() As Nullable(Of Integer)
        Property UnitsOnOrder() As Nullable(Of Integer)
        Property ReorderLevel() As Nullable(Of Integer)
        Property Discontinued() As Boolean
        ReadOnly Property Supplier() As Supplier
        ReadOnly Property Category() As Category
    End Interface
End Namespace
