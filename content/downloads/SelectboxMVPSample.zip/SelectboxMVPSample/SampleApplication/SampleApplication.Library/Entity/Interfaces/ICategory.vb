﻿Imports SampleApplication.Library.Entity

Namespace Entity.Interfaces
  Interface ICategory
    Property ID() As Integer
    Property CategoryName() As String
    Property Description() As String
  End Interface
End Namespace
