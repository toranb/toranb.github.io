﻿Imports SampleApplication.Library.DataAccess.Interfaces
Imports SampleApplication.Library.Entity

Namespace DataAccess
  Public Class CategoryRepository
        Implements ICategoryRepository

        Public Sub DeleteCategoryByID(ByVal id As Integer) Implements ICategoryRepository.DeleteCategoryByID

        End Sub

        Public Function GetCategoryById(ByVal id As Integer) As Category Implements ICategoryRepository.GetCategoryById

        End Function

        Public Function GetCategoryCollection() As IEnumerable(Of Category) Implements ICategoryRepository.GetCategoryCollection
            Dim CategoryCollection As New List(Of Category)

            CategoryCollection.Add(New Category With {.ID = 1, .CategoryName = "stuff", .Description = "stuff"})
            CategoryCollection.Add(New Category With {.ID = 2, .CategoryName = "stuff2", .Description = "stuff2"})
            CategoryCollection.Add(New Category With {.ID = 3, .CategoryName = "stuff3", .Description = "stuff3"})
            CategoryCollection.Add(New Category With {.ID = 4, .CategoryName = "stuff4", .Description = "stuff4"})

            Return CategoryCollection
        End Function

        Public Sub SaveCategory(ByVal CategoryObject As Category) Implements ICategoryRepository.SaveCategory

        End Sub

        Public Sub ClearCategoryCollection() Implements ICategoryRepository.ClearCategoryCollection

        End Sub

        Public Function GetCategoryByProductID(ByVal id As Integer) As Category Implements ICategoryRepository.GetCategoryByProductID

        End Function

    End Class
End Namespace