﻿Imports SampleApplication.Library.Entity

Namespace DataAccess.Interfaces
    Public Interface IProductRepository
        Function GetProductCollection() As IEnumerable(Of Product)
        Function GetProductById(ByVal id As Integer) As Product
        Sub SaveProduct(ByVal ProductObject As Product)
        Sub DeleteProductByID(ByVal id As Integer)
        Sub ClearProductCollection()
    End Interface
End Namespace
