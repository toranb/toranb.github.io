﻿Imports SampleApplication.Library.Entity

Namespace DataAccess.Interfaces
  Public Interface ICategoryRepository
    Function GetCategoryCollection() As IEnumerable(Of Category)
    Function GetCategoryById(ByVal id As Integer) As Category
    Sub SaveCategory(ByVal CategoryObject As Category)
    Sub DeleteCategoryByID(ByVal id As Integer)
    Sub ClearCategoryCollection()
    Function GetCategoryByProductID(ByVal id As Integer) As Category
  End Interface
End Namespace
