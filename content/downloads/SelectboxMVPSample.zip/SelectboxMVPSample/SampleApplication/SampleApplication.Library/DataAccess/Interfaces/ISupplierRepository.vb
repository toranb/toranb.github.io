﻿Imports SampleApplication.Library.Entity

Namespace DataAccess.Interfaces
  Public Interface ISupplierRepository
    Function GetSupplierCollection() As IEnumerable(Of Supplier)
    Function GetSupplierById(ByVal id As Integer) As Supplier
    Sub SaveSupplier(ByVal SupplierObject As Supplier)
    Sub DeleteSupplierByID(ByVal id As Integer)
    Sub ClearSupplierCollection()
    Function GetSupplierByProductID(ByVal id As Integer) As Supplier
  End Interface
End Namespace
