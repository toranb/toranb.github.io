﻿Imports SampleApplication.Library.DataAccess.Interfaces
Imports SampleApplication.Library.Entity

Namespace DataAccess
  Public Class SupplierRepository
        Implements ISupplierRepository

        Public Sub DeleteSupplierByID(ByVal id As Integer) Implements ISupplierRepository.DeleteSupplierByID

        End Sub

        Public Function GetSupplierById(ByVal id As Integer) As Supplier Implements ISupplierRepository.GetSupplierById

        End Function

        Public Function GetSupplierCollection() As IEnumerable(Of Supplier) Implements ISupplierRepository.GetSupplierCollection
            Dim SupplierCollection As New List(Of Supplier)

            SupplierCollection.Add(New Supplier With {.ID = 1, .CompanyName = "first"})
            SupplierCollection.Add(New Supplier With {.ID = 2, .CompanyName = "second"})
            SupplierCollection.Add(New Supplier With {.ID = 3, .CompanyName = "third"})
            SupplierCollection.Add(New Supplier With {.ID = 4, .CompanyName = "fourth"})

            Return SupplierCollection
        End Function

        Public Sub SaveSupplier(ByVal SupplierObject As Supplier) Implements ISupplierRepository.SaveSupplier

        End Sub

        Public Sub ClearSupplierCollection() Implements ISupplierRepository.ClearSupplierCollection

        End Sub

        Public Function GetSupplierByProductID(ByVal id As Integer) As Supplier Implements ISupplierRepository.GetSupplierByProductID

        End Function

    End Class
End Namespace