﻿Imports SampleApplication.Library.Entity
Imports SampleApplication.Library.Components.LookupList.Interfaces

Namespace View.Interfaces
    Public Interface IProductView
        Property ID() As Integer
        Property ProductName() As String
        Property QuantityPerUnit() As String
        Property UnitPrice() As Nullable(Of Decimal)
        Property UnitsInStock() As Nullable(Of Integer)
        Property UnitsOnOrder() As Nullable(Of Integer)
        Property ReorderLevel() As Nullable(Of Integer)
        Property Discontinued() As Boolean
        '** gridview specific components
        Property ProductCollection() As List(Of Product)
        ReadOnly Property SortExpression() As String
        ReadOnly Property SortDirection() As String
        '** ddl specific properties
        ReadOnly Property SupplierCollection() As ILookupList
        ReadOnly Property CategoryCollection() As ILookupList
        '** xml return for ajax work
        Property ReturnXML() As String
        '** ajax specific properties
        ReadOnly Property SelectedSupplier() As Integer
        ReadOnly Property SelectedCategory() As Integer
    End Interface
End Namespace
