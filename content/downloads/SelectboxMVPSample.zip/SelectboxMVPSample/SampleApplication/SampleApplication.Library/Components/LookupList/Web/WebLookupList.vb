﻿Imports SampleApplication.Library.Components.LookupList.Interfaces
Imports System.Web.UI.WebControls

Namespace Components.LookupList.Web
    Public Class WebLookupList
        Implements ILookupList

        Private ReadOnly listControl As ListControl

        Public Sub New(ByVal listControl As ListControl)
            Me.listControl = listControl
        End Sub

        Public Sub Clear() Implements ILookupList.Clear
            listControl.Items.Clear()
        End Sub

        Public Sub Add(ByVal dto As Interfaces.ILookupDTO) Implements Interfaces.ILookupList.Add
            listControl.Items.Add(New ListItem(dto.Text, dto.Value))
        End Sub

        Public Function Count() As Integer Implements Interfaces.ILookupList.Count
            Return listControl.Items.Count
        End Function

        Public Property SelectedIndex() As Integer Implements Interfaces.ILookupList.SelectedIndex
            Get
                Return listControl.SelectedIndex
            End Get
            Set(ByVal value As Integer)
                listControl.SelectedIndex = value
            End Set
        End Property

        Public Property SelectedValue() As String Implements Interfaces.ILookupList.SelectedValue
            Get
                Return listControl.SelectedValue
            End Get
            Set(ByVal value As String)
                listControl.SelectedValue = value
            End Set
        End Property
    End Class
End Namespace
