﻿'Imports SampleApplication.Library.Components.LookupList.Interfaces
'Imports System.Windows.Controls

'Namespace Components.LookupList.WPF
'    Public Class WPFLookupList
'        Implements ILookupList

'        Private ReadOnly combobox As ComboBox

'        Public Sub New(ByVal combobox As ComboBox)
'            Me.combobox = combobox
'        End Sub

'        Public Sub Add(ByVal dto As Interfaces.ILookupDTO) Implements Interfaces.ILookupList.Add
'            Dim item As New ComboBoxItem()
'            item.Content = dto.Text
'            item.Tag = dto.Value

'            combobox.Items.Add(item)
'        End Sub

'        Public Sub Clear() Implements Interfaces.ILookupList.Clear
'            combobox.Items.Clear()
'        End Sub

'        Public Function Count() As Integer Implements Interfaces.ILookupList.Count
'            Return combobox.Items.Count
'        End Function

'        Public Property SelectedIndex() As Integer Implements Interfaces.ILookupList.SelectedIndex
'            Get
'                Return combobox.SelectedIndex
'            End Get
'            Set(ByVal value As Integer)
'                combobox.SelectedIndex = value
'            End Set
'        End Property

'        Public Property SelectedValue() As String Implements Interfaces.ILookupList.SelectedValue
'            Get
'                Return combobox.SelectedValue.Tag
'            End Get
'            Set(ByVal value As String)
'                combobox.SelectedValue.Tag = value
'            End Set
'        End Property
'    End Class
'End Namespace

