﻿Imports SampleApplication.Library.Components.LookupList.Interfaces

Namespace Components.LookupList
    Public Class LookupCollection
        Private ReadOnly dtos As IEnumerable(Of ILookupDTO)
        Private mList As ILookupList

        Public Sub New(ByVal dtos As IEnumerable(Of ILookupDTO))
            Me.dtos = dtos
        End Sub

        Public Sub BindTo(ByVal list As ILookupList)
            mList = list

            mList.Clear()

            For Each dto As ILookupDTO In dtos
                mList.Add(dto)
            Next
        End Sub

        Public Property SelectedIndex() As Integer
            Get
                Return mList.SelectedIndex
            End Get
            Set(ByVal value As Integer)
                mList.SelectedIndex = value
            End Set
        End Property

        Public Property SelectedValue() As String
            Get
                Return mList.SelectedValue
            End Get
            Set(ByVal value As String)
                mList.SelectedValue = value
            End Set
        End Property
    End Class
End Namespace
