﻿Namespace Components.LookupList.Interfaces
    Public Interface ILookupDTO
        Property Text() As String
        Property Value() As String
    End Interface
End Namespace
