﻿Namespace Components.LookupList.Interfaces
    Public Interface ILookupList
        Sub Add(ByVal dto As ILookupDTO)
        Sub Clear()
        Function Count() As Integer
        Property SelectedIndex() As Integer
        Property SelectedValue() As String
    End Interface
End Namespace