﻿Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Runtime.Serialization
Imports SampleApplication.Library.Components.LookupList.Interfaces

Namespace Components.Entities
    Public Class LookupDTO
        Implements ILookupDTO

        Private mText As String
        Private mValue As String

        ''' <summary>
        ''' This constr is used when you want to create a new LookupCollection of ILookupDTO
        ''' </summary>
        ''' <param name="txt"></param>
        ''' <param name="val"></param>
        ''' <remarks></remarks>
        Public Sub New(ByVal txt As String, ByVal val As String)
            mText = txt
            mValue = val
        End Sub

        Public Property Text() As String Implements Components.LookupList.Interfaces.ILookupDTO.Text
            Get
                Return mText
            End Get
            Set(ByVal value As String)
                mText = value
            End Set
        End Property

        Public Property Value() As String Implements Components.LookupList.Interfaces.ILookupDTO.Value
            Get
                Return mValue
            End Get
            Set(ByVal value As String)
                mValue = value
            End Set
        End Property
    End Class
End Namespace