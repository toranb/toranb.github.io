﻿Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Entity
Imports Persistence.BaseRepository
Imports NHibernate

Namespace DataAccess
    Public Class CheckingAccountRepository
        Inherits NHibernateRepository(Of CheckingAccount)
        Implements ICheckingAccountRepository

        Public Sub New()
            MyBase.New()
        End Sub

        Public Sub New(ByVal Session As ISession, ByVal Transaction As ITransaction)
            MyBase.New(Session, Transaction)
        End Sub

        Public Sub DeleteCheckingAccount(ByVal CheckingAccount As CheckingAccount) Implements ICheckingAccountRepository.DeleteCheckingAccount
            MyBase.Delete(CheckingAccount)
        End Sub

        Public Function GetCheckingAccountById(ByVal id As Integer) As CheckingAccount Implements ICheckingAccountRepository.GetCheckingAccountById
            Return MyBase.Retrieve(id)
        End Function

        Public Function GetCheckingAccountCollection() As IQueryable(Of CheckingAccount) Implements ICheckingAccountRepository.GetCheckingAccountCollection
            Return MyBase.RetrieveAll()
        End Function

        Public Sub SaveCheckingAccount(ByVal CheckingAccount As CheckingAccount) Implements ICheckingAccountRepository.SaveCheckingAccount
            MyBase.Save(CheckingAccount)
        End Sub

    End Class
End Namespace