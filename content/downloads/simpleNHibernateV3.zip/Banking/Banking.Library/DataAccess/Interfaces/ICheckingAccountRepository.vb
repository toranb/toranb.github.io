﻿Imports Banking.Library.Entity

Namespace DataAccess.Interfaces
    Public Interface ICheckingAccountRepository
        Function GetCheckingAccountCollection() As IQueryable(Of CheckingAccount)
        Function GetCheckingAccountById(ByVal id As Integer) As CheckingAccount
        Sub SaveCheckingAccount(ByVal CheckingAccount As CheckingAccount)
        Sub DeleteCheckingAccount(ByVal CheckingAccount As CheckingAccount)
    End Interface
End Namespace
