﻿Imports Banking.Library.Entity

Namespace Entity.Interfaces
    Public Interface IUser
        Property ID() As Integer
        Property FirstName() As String
        Property LastName() As String
        Property Address() As String
        Property City() As String
        Property State() As String
        Property Zip() As String
        Property Phone() As String
    End Interface
End Namespace
