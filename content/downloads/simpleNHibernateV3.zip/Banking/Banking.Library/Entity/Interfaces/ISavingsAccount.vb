﻿Imports Banking.Library.Entity

Namespace Entity.Interfaces
    Public Interface ISavingsAccount
        Property ID() As Integer
        Property SavingsInfo() As String
    End Interface
End Namespace
