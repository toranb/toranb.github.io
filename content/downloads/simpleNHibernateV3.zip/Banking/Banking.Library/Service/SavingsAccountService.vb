﻿Imports Banking.Library.DataAccess
Imports Banking.Library.Entity
Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Service.Interfaces

Namespace Service
    Public Class SavingsAccountService
        Implements ISavingsAccountService

        Private mRepository As ISavingsAccountRepository

        Public Sub New()
            Me.New(New SavingsAccountRepository())
        End Sub

        Public Sub New(ByVal Repository As ISavingsAccountRepository)
            mRepository = Repository
        End Sub

        Public Sub DeleteSavingsAccount(ByVal SavingsAccount As SavingsAccount) Implements ISavingsAccountService.DeleteSavingsAccount
            mRepository.DeleteSavingsAccount(SavingsAccount)
        End Sub

        Public Function GetSavingsAccountById(ByVal id As Integer) As SavingsAccount Implements ISavingsAccountService.GetSavingsAccountById
            Return mRepository.GetSavingsAccountById(id)
        End Function

        Public Function GetSavingsAccountCollection() As IQueryable(Of SavingsAccount) Implements ISavingsAccountService.GetSavingsAccountCollection
            Return mRepository.GetSavingsAccountCollection()
        End Function

        Public Sub SaveSavingsAccount(ByVal SavingsAccount As SavingsAccount) Implements ISavingsAccountService.SaveSavingsAccount
            mRepository.SaveSavingsAccount(SavingsAccount)
        End Sub

    End Class
End Namespace
