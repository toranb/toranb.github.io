﻿Imports Banking.Library.DataAccess
Imports Banking.Library.Entity
Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Service.Interfaces

Namespace Service
    Public Class UserService
        Implements IUserService

        Private mRepository As IUserRepository

        Public Sub New()
            Me.New(New UserRepository())
        End Sub

        Public Sub New(ByVal Repository As IUserRepository)
            mRepository = Repository
        End Sub

        Public Sub DeleteUser(ByVal User As User) Implements IUserService.DeleteUser
            mRepository.DeleteUser(User)
        End Sub

        Public Function GetUserById(ByVal id As Integer) As User Implements IUserService.GetUserById
            Return mRepository.GetUserById(id)
        End Function

        Public Function GetUserCollection() As IQueryable(Of User) Implements IUserService.GetUserCollection
            Return mRepository.GetUserCollection()
        End Function

        Public Sub SaveUser(ByVal User As User) Implements IUserService.SaveUser
            mRepository.SaveUser(User)
        End Sub

    End Class
End Namespace
