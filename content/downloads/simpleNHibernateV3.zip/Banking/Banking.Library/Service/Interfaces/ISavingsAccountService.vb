﻿Imports Banking.Library.Entity

Namespace Service.Interfaces
    Public Interface ISavingsAccountService
        Function GetSavingsAccountCollection() As IQueryable(Of SavingsAccount)
        Function GetSavingsAccountById(ByVal id As Integer) As SavingsAccount
        Sub SaveSavingsAccount(ByVal SavingsAccount As SavingsAccount)
        Sub DeleteSavingsAccount(ByVal SavingsAccount As SavingsAccount)
    End Interface
End Namespace
