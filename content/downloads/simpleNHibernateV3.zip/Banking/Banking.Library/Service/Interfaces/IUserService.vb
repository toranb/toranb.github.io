﻿Imports Banking.Library.Entity

Namespace Service.Interfaces
    Public Interface IUserService
        Function GetUserCollection() As IQueryable(Of User)
        Function GetUserById(ByVal id As Integer) As User
        Sub SaveUser(ByVal User As User)
        Sub DeleteUser(ByVal User As User)
    End Interface
End Namespace
