Imports Banking.Library.Service.Interfaces
Imports Banking.Library.Service
Imports Banking.Library.Entity
Imports NHibernate
Imports NHibernate.Linq
Imports System.IO
Imports System.Text
Imports System
Imports Persistence.SessionBuilder.Interfaces
Imports Persistence.SessionBuilder

<HandleError()> _
Public Class UserController
    Inherits System.Web.Mvc.Controller

    Private mUserService As IUserService

    Public Sub New()
        Me.New(New UserService())
    End Sub

    Public Sub New(ByVal UserService As IUserService)
        mUserService = UserService
    End Sub

    '
    ' GET: /User/

    Function Index() As ActionResult
        Dim UserList As List(Of User) = mUserService.GetUserCollection.Where(Function(x) x.State.Equals("IA")).ToList()

        Return View(UserList)
    End Function

    '
    ' GET: /User/Edit

    Function Edit(ByVal id As Integer) As ActionResult
        Dim User As User = mUserService.GetUserById(id)

        Return View(User)
    End Function

    '
    ' POST: /User/Edit/1

    <AcceptVerbs(HttpVerbs.Post)> _
    Function Edit(ByVal id As Integer, ByVal collection As FormCollection) As ActionResult
        Dim User As User = mUserService.GetUserById(id)

        User.Address = "1016 Cameron"

        mUserService.SaveUser(User)

        Return View(User)
    End Function

    '
    ' POST: /User/Delete/1

    <AcceptVerbs(HttpVerbs.Post)> _
    Function Delete(ByVal id As Integer) As ActionResult
        Dim User As User = mUserService.GetUserById(id)

        mUserService.DeleteUser(User)

        Return View()
    End Function

    '
    ' POST: /User/Create/1

    <AcceptVerbs(HttpVerbs.Post)> _
    Function Create(ByVal collection As FormCollection) As ActionResult
        Dim NewUser As New User With {.FirstName = "John", .LastName = "Doe", .Address = "400 N. 1st", .City = "Des Moines", .State = "IA", .Zip = "50309", .Phone = "5154010344"}

        mUserService.SaveUser(NewUser)

        Return View()
    End Function

End Class
