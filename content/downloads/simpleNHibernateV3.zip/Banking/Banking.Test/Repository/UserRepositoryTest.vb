﻿Imports System
Imports Banking
Imports System.Text
Imports System.Web.Mvc
Imports Banking.Library.Entity
Imports System.Collections.Generic
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports Banking.Library.Service.Interfaces
Imports Persistence.Testing
Imports Banking.Library.DataAccess

<TestClass()> _
Public Class UserRepositoryTest
    Inherits NHibernateTransactionFixture

    <TestMethod()> _
    Public Sub Should_Exercise_The_UserRepository_Methods()
        Dim Repository As UserRepository = New UserRepository(mSession, mTransaction)
        '**
        '** First clear the table so we can assure this test is accurate **'
        '**
        mSession.CreateQuery("delete from User").ExecuteUpdate()
        '**
        '** Verify the table was cleared after the above method was executed **'
        '**
        Dim InitUserCollection As List(Of User) = Repository.GetUserCollection().ToList()
        Assert.AreEqual(0, InitUserCollection.Count)
        '**
        '** Create a new user object to manipulate throughout the test **'
        '**
        Dim UserObject As New User()
        UserObject.FirstName = "John"
        UserObject.LastName = "Doe"
        '**
        '** Save the user
        '**
        Repository.SaveUser(UserObject)
        '**
        '** Verify the user was saved after the above method was executed **'
        '**
        Dim NextUserObject As User = Repository.GetUserById(UserObject.ID)
        Assert.AreEqual(NextUserObject.FirstName, "John")
        Assert.AreEqual(NextUserObject.LastName, "Doe")
        '**
        '** Get a collection of users **'
        '**
        Dim UserCollection As List(Of User) = Repository.GetUserCollection().ToList()
        '**
        '** Verify the collection was populated after the above method was executed **'
        '**
        Assert.AreEqual(UserCollection.Count, 1)
        Assert.AreEqual(UserCollection(0).ID, NextUserObject.ID)
        '**
        '** Delete the user **'
        '**
        Repository.DeleteUser(NextUserObject)
        '**
        '** verify it worked **'
        '**
        Dim NullUserObject As User = Repository.GetUserById(NextUserObject.ID)
        '**
        '** Verify the user was deleted after the delete method was executed **'
        '**
        Assert.AreEqual(Nothing, NullUserObject)
    End Sub

End Class
