Imports Banking.Library.Service.Interfaces
Imports Banking.Library.Service
Imports Banking.Library.Entity
Imports NHibernate
Imports NHibernate.Linq
Imports System.IO
Imports System.Text
Imports System

<HandleError()> _
Public Class UserController
    Inherits System.Web.Mvc.Controller

    '
    ' GET: /User/

    Function Index() As ActionResult
        Dim UserList As List(Of User)
        Dim mSession As ISession
        Dim mSessionFactory As ISessionFactory

        Dim configuration = New Cfg.Configuration()

        configuration.Configure("C:\Documents and Settings\User\My Documents\Visual Studio 2008\Projects\Banking\Banking.Test\app.config")
        'configuration.Configure("C:\Documents and Settings\User\My Documents\Visual Studio 2008\Projects\Banking\Banking\Web.config")

        mSessionFactory = configuration.BuildSessionFactory()

        mSession = mSessionFactory.OpenSession()

        Try
            mSession.BeginTransaction()

            'do our first query using LINQ to NHibernate
            Dim query As IQueryable(Of User) = From Item In mSession.Linq(Of User)() _
                                               Select Item

            query = query.Where(Function(x) x.State.Equals("IA"))

            UserList = query.ToList()

            mSession.Transaction.Commit()
        Catch ex As Exception
            mSession.Transaction.Rollback()
        Finally
            mSession.Close()
        End Try

        Return View(UserList)
    End Function

    Function Edit() As ActionResult
        Dim User As User
        Dim mSession As ISession
        Dim mSessionFactory As ISessionFactory

        Dim configuration = New Cfg.Configuration()

        configuration.Configure("C:\Documents and Settings\User\My Documents\Visual Studio 2008\Projects\Banking\Banking.Test\app.config")
        'configuration.Configure("C:\Documents and Settings\User\My Documents\Visual Studio 2008\Projects\Banking\Banking\Web.config")

        mSessionFactory = configuration.BuildSessionFactory()

        mSession = mSessionFactory.OpenSession()

        Try
            mSession.BeginTransaction()

            'do our first query
            User = mSession.Get(Of User)(1)

            mSession.Transaction.Commit()
        Catch ex As Exception
            mSession.Transaction.Rollback()
        Finally
            mSession.Close()
        End Try

        Return View(User)
    End Function

End Class
