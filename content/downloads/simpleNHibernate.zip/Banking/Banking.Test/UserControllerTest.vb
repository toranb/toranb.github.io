﻿Imports System
Imports Banking
Imports System.Text
Imports System.Web.Mvc
Imports Banking.Library.Entity
Imports System.Collections.Generic
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()> _
Public Class UserControllerTest

    <TestMethod()> _
    Public Sub Should_Query_User_By_Id()
        Dim Controller As UserController = New UserController()

        Dim Result As ViewResult = Controller.Edit()

        Dim Model As User = DirectCast(Result.ViewData.Model, User)

        Assert.AreEqual(Model.ID, 1)
        Assert.AreEqual(Model.FirstName, "Toran")
        Assert.AreEqual(Model.LastName, "Billups")
        Assert.AreEqual(Model.Address, "3402 Ash DR SW")
        Assert.AreEqual(Model.City, "Bondurant")
        Assert.AreEqual(Model.State, "IA")
        Assert.AreEqual(Model.Zip, "50035")
        Assert.AreEqual(Model.Phone, "5157795670")
    End Sub

    <TestMethod()> _
    Public Sub Should_Query_User_Collection_Using_LINQ()
        Dim Controller As UserController = New UserController()

        Dim Result As ViewResult = Controller.Index()

        Dim Model As IEnumerable(Of User) = DirectCast(Result.ViewData.Model, IEnumerable(Of User))

        Assert.AreEqual(Model.Count, 1)
        Assert.AreEqual(Model(0).ID, 1)
        Assert.AreEqual(Model(0).FirstName, "Toran")
        Assert.AreEqual(Model(0).LastName, "Billups")
        Assert.AreEqual(Model(0).Address, "3402 Ash DR SW")
        Assert.AreEqual(Model(0).City, "Bondurant")
        Assert.AreEqual(Model(0).State, "IA")
        Assert.AreEqual(Model(0).Zip, "50035")
        Assert.AreEqual(Model(0).Phone, "5157795670")
    End Sub

End Class
