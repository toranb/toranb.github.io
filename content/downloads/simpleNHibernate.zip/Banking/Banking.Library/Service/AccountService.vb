﻿Imports Banking.Library.DataAccess
Imports Banking.Library.Entity
Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Service.Interfaces

Namespace Service
    Public Class AccountService
        Implements IAccountService

        Private mRepository As IAccountRepository

        Public Sub New()
            Me.New(New AccountRepository())
        End Sub

        Public Sub New(ByVal Repository As IAccountRepository)
            mRepository = Repository
        End Sub

        Public Sub DeleteAccount(ByVal Account As Account) Implements IAccountService.DeleteAccount
            mRepository.DeleteAccount(Account)
        End Sub

        Public Function GetAccountById(ByVal id As Integer) As Account Implements IAccountService.GetAccountById
            Return mRepository.GetAccountById(id)
        End Function

        Public Function GetAccountCollection() As IQueryable(Of Account) Implements IAccountService.GetAccountCollection
            Return mRepository.GetAccountCollection()
        End Function

        Public Sub SaveAccount(ByVal Account As Account) Implements IAccountService.SaveAccount
            mRepository.SaveAccount(Account)
        End Sub

    End Class
End Namespace
