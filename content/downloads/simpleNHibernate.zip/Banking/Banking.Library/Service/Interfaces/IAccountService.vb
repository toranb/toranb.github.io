﻿Imports Banking.Library.Entity

Namespace Service.Interfaces
    Public Interface IAccountService
        Function GetAccountCollection() As IQueryable(Of Account)
        Function GetAccountById(ByVal id As Integer) As Account
        Sub SaveAccount(ByVal Account As Account)
        Sub DeleteAccount(ByVal Account As Account)
    End Interface
End Namespace
