﻿Imports Banking.Library.DataAccess.Interfaces
Imports Banking.Library.Entity
Imports Persistence.BaseRepository
Imports NHibernate

Namespace DataAccess
    Public Class SavingsAccountRepository
        Inherits NHibernateRepository(Of SavingsAccount)
        Implements ISavingsAccountRepository

        Public Sub New()
            MyBase.New()
        End Sub

        Public Sub New(ByVal Session As ISession, ByVal Transaction As ITransaction)
            MyBase.New(Session, Transaction)
        End Sub

        Public Sub DeleteSavingsAccount(ByVal SavingsAccount As SavingsAccount) Implements ISavingsAccountRepository.DeleteSavingsAccount
            MyBase.Delete(SavingsAccount)
        End Sub

        Public Function GetSavingsAccountById(ByVal id As Integer) As SavingsAccount Implements ISavingsAccountRepository.GetSavingsAccountById
            Return MyBase.Retrieve(id)
        End Function

        Public Function GetSavingsAccountCollection() As IQueryable(Of SavingsAccount) Implements ISavingsAccountRepository.GetSavingsAccountCollection
            Return MyBase.RetrieveAll()
        End Function

        Public Sub SaveSavingsAccount(ByVal SavingsAccount As SavingsAccount) Implements ISavingsAccountRepository.SaveSavingsAccount
            MyBase.Save(SavingsAccount)
        End Sub

    End Class
End Namespace