﻿Imports Banking.Library.Entity

Namespace DataAccess.Interfaces
    Public Interface IAccountRepository
        Function GetAccountCollection() As IQueryable(Of Account)
        Function GetAccountById(ByVal id As Integer) As Account
        Sub SaveAccount(ByVal Account As Account)
        Sub DeleteAccount(ByVal Account As Account)
    End Interface
End Namespace
