﻿Imports Banking.Library.Entity

Namespace Entity.Interfaces
    Public Interface IAccount
        Property BaseID() As Integer
        Property Description() As String
        Property Balance() As Decimal
        Property UserID() As Integer
    End Interface
End Namespace
